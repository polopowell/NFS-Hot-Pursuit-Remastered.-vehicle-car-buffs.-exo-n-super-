# NFS Hot Pursuit Remastered — Handling & Drift Tuning Guide

---

## How the File System Works

The game stores vehicle and gameplay logic data in `.BIN` and `.BNDL` bundle files inside the game directories. These bundles contain multiple resource types packed together. The `bundle_packer_unpacker.py` tool is used to unpack them into editable `.dat` files and repack them back.

### Vehicle Bundles (in `VEHICLES/`):
Each vehicle has three bundles:
- `VEH_XXXXXX_MS.BIN` — Main stream (physics, handling, geometry)
- `VEH_XXXXXX_EN.BIN` — Engine/audio stream
- `VEH_XXXXXX_ENCMP.BIN` — Compressed engine stream

**All handling and drift data lives in the MS bundle.**

### Gameplay Logic Bundles (in `GAMELOGIC/`):
Global systems (such as weapons, AI, and nitrous parameters) are packed in logical BNDL files.
- `GAMEPLAY.BNDL` — Contains global configurations including nitrous regeneration rates and scoring multipliers.

---

## The Genesys System

Handling and gameplay data uses Criterion's "Genesys" data system. It has two file types:

### GenesysDefinition (`.dat` in `GenesysDefinition/`)
Schema files — describe what fields exist, their types (float, bool, etc.), and byte offsets within instance data. Field names are stored as plain strings inside these files.

### GenesysInstance (`.dat` in `GenesysInstance/`)
Data files — contain the actual values, laid out in binary according to their paired Definition. An instance references its definition by embedding the definition's 4-byte hash ID in its header.

---

## Workflow: Making a Change

### 1. Unpack the bundle
```
cd handling_tools
python bundle_packer_unpacker.py -u hpr "../VEHICLES/VEH_XXXXXX_MS.BIN" "CarName/MS"
```

### 2. Find the relevant instance file
Search for the definition type hash inside the GenesysInstance directory:
```python
import os

target = b'\xA2\x8A\x01\x00'  # DriftBehaviour type hash
inst_dir = 'CarName/MS/GenesysInstance'
for fn in sorted(os.listdir(inst_dir)):
    with open(os.path.join(inst_dir, fn), 'rb') as f:
        data = f.read()
    if target in data:
        print(fn)  # this is your drift file
```

**Known definition type hashes:**
| Behaviour | Hash bytes | Hex ID |
|---|---|---|
| DriftBehaviour | `A2 8A 01 00` | `0x00018AA2` |
| HandlingBehaviour | `A8 8A 01 00` | `0x00018AA8` |
| Tyre | `9F 8A 01 00` | `0x00018A9F` |
| SteeringBehaviour | `AA 8A 01 00` | `0x00018AAA` |
| BrakeBehaviour | `A5 8A 01 00` | `0x00018AA5` |
| HandbrakeAbility | `B1 8A 01 00` | `0x00018AB1` |
| Engine | `98 8A 01 00` | `0x00018A98` |
| HardDrivingBehaviour | `D2 78 02 00` | `0x000278D2` |
| NitrousParameters | `10 46 06 00` | `0x00064610` |

### 3. Back up before editing
```python
import shutil
shutil.copy2('path/to/file.dat', 'path/to/file.dat.bak')
```

### 4. Edit values
All values are **little-endian 32-bit floats** (`<f` in Python struct format):
```python
import struct

with open('CarName/MS/GenesysInstance/XX_XX_XX_XX.dat', 'rb') as f:
    data = bytearray(f.read())

struct.pack_into('<f', data, 0x240, 3.6)  # write float 3.6 at offset 0x240

with open('CarName/MS/GenesysInstance/XX_XX_XX_XX.dat', 'wb') as f:
    f.write(data)
```

### 5. Repack the bundle
```
python bundle_packer_unpacker.py -p hpr "CarName/MS/IDs_VEH_XXXXXX_MS.json" "." "CarName.BNDL"
```

### 6. Install to game
Verify platform byte at offset `0x08` of the repacked file is set to `0x01` (PC format), then place in the appropriate game folder.

---

## DriftBehaviour Structure

The DriftBehaviour instance contains six sub-blocks. The offsets below are consistent across all vehicles tested (Viper ACR, Zonda Cinque, Diablo).

---

### Block 1 — Drift_trigger (offset `0x90`)

Controls the conditions that **initiate** drift state.

| Field | Offset | Type | Description |
|-------|--------|------|-------------|
| [0] | `0x90` | float | Minimum speed threshold to enter drift state |
| [1] | `0x94` | bool | Enabled flag |
| [2] | `0x95` | bool | Secondary flag |

**Notes:**
- Raising `[0]` means the car requires more slide/speed before entering drift state — reduces accidental triggers at normal cornering speeds. A value of `53–55` is a good subtle increase from the typical stock `50.0`.

---

### Block 2 — Drift_scale (offset `0xD0`)

Multipliers applied to various forces **while in drift state**.

| Field | Offset | Type | Description |
|-------|--------|------|-------------|
| [0] | `0x0D0` | float | Drag/resistance scale during drift |
| [1] | `0x0D4` | float | Yaw force amplification |
| [2] | `0x0D8` | float | Lateral slide width scale |
| [3] | `0x0DC` | float | Brake drag scale during drift |
| [4] | `0x0E0` | float | Secondary force scale |
| [5] | `0x0E4` | float | (unused, leave at 0) |
| [6] | `0x0E8` | float | (unused, leave at 0) |

**Important — learned from testing:**
- `[0]` is a **drag/resistance multiplier**, NOT a grip scale. Higher = more drag during drift = slower. Lower = less drag = faster through drift. Do NOT raise this expecting more grip — it makes the car slower.
- `[1]` amplifies yaw forces during drift. `1.0` = neutral. `1.1` = 10% snappier rotation. Values below `1.0` feel smoother, calmer, and allow a more forward-pointed, gliding posture.
- `[2]` controls how wide the car slides laterally. High values (e.g. `1.2`) cause wide uncontrolled slides. Reducing toward `0.80–0.90` gives tighter, more directed drifts, preventing the car from hitting outer walls.
- `[3]` is a brake drag multiplier during drift. Higher = more braking force = slower. Leave at stock unless specifically tuning deceleration in drift.

---

### Block 3 — Yaw_torque (offset `0x120`)

The **rotational spin force** applied during drift to help maintain the slide angle.

| Field | Offset | Type | Description |
|-------|--------|------|-------------|
| [0] | `0x120` | float | Minimum slip threshold |
| [1] | `0x124` | float | Torque ramp start |
| [2] | `0x128` | float | Torque ramp end (full force) |
| [3] | `0x12C` | float | Torque damping coefficient |
| [4] | `0x130` | float | (unused) |
| [5] | `0x134` | float | Primary yaw torque magnitude |
| [6] | `0x138` | float | Counter yaw torque (resistance/damping) |
| [7] | `0x13C` | float | (unused) |
| [8] | `0x140` | float | (unused) |

**Notes:**
- `[5]` is the main spin character lever. Raising it makes the car rotate more aggressively during drift. Each car has its own tuned value — the Zonda (32000) spins more than the Viper (26000) by design.
- `[6]` is counter-torque damping. Raising it makes the drift angle more stable and controlled (tighter feel), but also makes the car exit drift state slightly sooner since it resists the slide more actively.

---

### Block 4 — Side_force (offset `0x180`)

Controls **lateral (sideways) forces** during drift.

| Field | Offset | Type | Description |
|-------|--------|------|-------------|
| [0] | `0x180` | float | Minimum lateral velocity threshold |
| [1] | `0x184` | float | Maximum lateral angle |
| [2] | `0x188` | float | Lateral force magnitude scale |
| [3] | `0x18C` | float | Lateral damping coefficient |
| [4] | `0x190` | float | Secondary threshold |
| [5] | `0x194` | float | Speed factor offset |
| [6] | `0x198` | float | Speed factor |
| [7] | `0x19C` | float | Minimum speed for side force |
| [8] | `0x1A0` | float | Maximum speed for side force |

**Notes:**
- `[2]` is the most impactful field in this block. Reducing this (e.g. `1.0` ➔ `0.80`) dramatically improves speed retention through and out of drifts because less kinetic energy is bled off laterally.

---

### Block 6 — Drift_exit (offset `0x240`)

Controls the conditions that **end** drift state and return the car to normal grip.

| Field | Offset | Type | Description |
|-------|--------|------|-------------|
| [0] | `0x240` | float | Exit threshold — lower = drift state ends later |
| [1] | `0x244` | float | (unused) |
| [2] | `0x248` | float | Exit scale multiplier |

**Notes:**
- **Lowering** this value increases drift duration and sustainability. It makes it harder to exit the drift state, allowing you to sustain long sweeps even with gentle counter-steer adjustments.
- Sweet spot for long drifts is `2.8–3.2`.

---

## Global Nitrous Recovery Tuning (`GAMEPLAY.BNDL`)

Nitrous recharge rates and threshold conditions are governed globally by the class `NitrousParameters` (hex ID `0x00064610`) inside `GAMELOGIC/GAMEPLAY.BNDL`. 

The configuration embeds pointers to sub-blocks that define refill rates (floats at sub-block offset `0x8` or `0x4` depending on structure) and minimum trigger speeds (floats at sub-block offset `0x4` or `0x8` depending on structure). 

### Refill Behavior Sub-Blocks:
1. **Drifting** (Field 4): Default refill rate is `0.5–0.7` units, with a minimum activation speed of `50 km/h`.
2. **TrafficOncoming** (Field 6): Governs oncoming lane refills. Default speed threshold is `100 km/h`.
3. **TrafficNearMiss** (Field 5): Default refill rate is `1.0–2.0` units, speed threshold `55–70 km/h`.
4. **Slipstreaming** (Field 14): Default refill rate is `2.0–3.0` units, speed threshold `70 km/h`.

### Nitrous Buff Profiles:
Depending on balance preferences, three main setups are supported:
* **Subtle +28% Profile (`1.28x`):** Scaled up by **+28%** across drifting, near-misses, and drafting. Oncoming lane rate is set to **`1.28`**. Speed thresholds are slightly lowered (triggering at `47/90/52/65 km/h` respectively).
* **OP +40% Profile (`1.40x`):** Scaled up by **+40%** across drifting, near-misses, and drafting. Oncoming lane rate is set to **`1.40`**. Speed thresholds are identical to the subtle setup.
* **Super OP +65% Profile (`1.65x`):** Scaled up by **+65%** across drifting, near-misses, and drafting. Oncoming lane rate is set to **`1.65`**. Speed thresholds are lowered further to trigger even faster (triggering at `45/85/50/60 km/h` respectively).


---

## Advanced Handling Dynamics: "F1/Downforce" Gliding

By combining high drift entry speeds with specific modifications to the chassis and lateral drift forces, we can simulate an aerodynamic **"virtual downforce"** effect.

### How to achieve the F1 Glide setup:
1. **Carry Maximum Momentum:** Set Drift Drag (`0xD0`) to `0.58` and Lateral Drag (`0x188`) to `0.80`. By reducing kinetic energy loss, the car flies through slides.
2. **Restrict Side Slippage (Breathing Room):** Set Slide Width (`0xD8`) to `0.85` (down from `0.90`). This keeps the slide narrow and prevents the car from washing out sideways into outer walls.
3. **Shallow Drift Angle:** Set Yaw Amplification (`0xD4`) to `0.98`. A shallower angle points the front tires more forward, allowing the car to "glide" smoothly down the road under high speed, making transitions and late apexes extremely precise.

---

## Car-Specific Reference

### Viper ACR — VEH_172882
**Drift instance:** `Viper/MS/GenesysInstance/6B_A3_02_00.dat`

#### Custom / F1 Gliding Viper Tunes (Based on Pre-Buff baseline)

| Variant | Drift Drag (`0xD0`) | Yaw Amp (`0xD4`) | Slide Width (`0xD8`) | Exit Delay (`0x240`) | Description |
|---|---|---|---|---|---|
| **Stock Pre-Buff** | `0.66` | `1.10` | `0.895` | `3.20` | Original loose muscle feel. Rotates strongly but bogs down early due to high drag. |
| **Test (Stage 1 Speed)** | `0.58` | `1.02` | `0.895` | `3.20` | Retains pre-buff steering and tyres. Significantly faster in drifts. |
| **Test 0 (Composed/Stock Power)**| `0.58` | `0.98` | `0.850` | `2.90` | **Handling Chassis only.** Exact F1-glide handling chassis from Test 3/2 but keeps engine power, torque, and speed governor completely stock (`600 HP` NOS, `720/800` torque, `202 m/s` governor). |
| **Test 2 (RB21 F1 Glide)**| `0.58` | `0.98` | `0.850` | `2.90` | **The Sweet Spot.** Tighter slide width prevents wall hits; shallower yaw creates a smooth gliding posture; exit delay lowered to `2.90` to hold long drifts effortlessly. Extremely intense and engaging. |

| **Test 2.5 (Balanced Glide/Power)**| `0.58` | `0.98` | `0.850` | `2.90` | **Balanced setup.** Maintains Test 3/2's F1 glide handling chassis but moderates performance buffs. Halfway between stock and OP: NOS Power (`700.0 HP` vs `600` stock/`800` OP), Base/Peak Torque (`745/830` vs `720/800` stock/`770/860` OP for +3.5% acceleration), speed governor raised by **`+5.4 km/h`** (`203.5 m/s` vs `202`). |
| **Test 3 (OP Glide/Power)**| `0.58` | `0.98` | `0.850` | `2.90` | **OP setup.** Integrates Test 2 handling but buffs engine performance: NOS Power (`800.0 HP` vs stock `600`), Base/Peak Torque (`770/860` vs `720/800` for +7% acceleration), and increases Top Speed governor by **`+10.8 km/h`** (`205 m/s` vs `202`). |
| **Test 4 (Super OP Glide/Power)**| `0.45` | `0.96` | `0.800` | `2.50` | **Extreme OP setup.** Extremely low drift drag (`0.45`), slippery lateral resistance (`0.70`), tight slide width (`0.80`), and massive exit delay (`2.50`). Engine performance is pushed to the limit: NOS Power (**`1100.0 HP`**), base/peak torque (**`900/1000`** for +25% acceleration), speed governor raised by **`+36.0 km/h`** (`212 m/s`). |



---

## Quick Reference: Tuning Goals

| Goal | Parameter | Direction | Notes |
|------|-----------|-----------|-------|
| Drift lasts longer | `Drift_exit[0]` `0x240` | Lower | Sweet spot: `2.8–3.2` |
| Drift exits sooner / easier recovery | `Drift_exit[0]` `0x240` | Raise | |
| More speed through/out of drift | `Side_force[2]` `0x188` | Lower | Main cause of speed loss (sweet spot: `0.70-0.80`) |
| More speed through/out of drift | `Drift_scale[0]` `0x0D0` | Lower | Reduces slide drag multiplier (sweet spot: `0.42-0.55`) |
| More speed through/out of drift | `Drift_scale[0]` `0x0D0` | **Do NOT raise** | Raising adds drag, slows car |
| Less brake slowdown in drift | `Drift_scale[3]` `0x0DC` | Lower | Reduces deceleration when braking in drift (sweet spot: `0.30-0.42`) |
| Tighter, more stable drift angle | `Yaw_torque[6]` `0x138` | Raise | Also slightly shortens drift |
| Less wide lateral slide (tighter line) | `Drift_scale[2]` `0x0D8` | Lower | Prevents washing out into walls; leaves road breathing room (`0.85`) |
| Shallower, gliding drift posture | `Drift_scale[1]` `0x0D4` | Lower | e.g. `0.98` makes F1-like glide; `1.10+` is loose drift. |
| Fewer accidental drift entries | `Drift_trigger[0]` `0x90` | Raise slightly | `50` ➔ `53–55` is subtle |
| Higher straight line acceleration | `NOS horsepower` `0x108` | Raise | Elevates nitrous boost (sweet spot: `800-980` hp) |

---

## Lessons Learned

1. **`Drift_scale[0]` is a drag multiplier, not a grip scale.** Raising it does not make the car feel more planted — it adds drag and slows the car down during drift.
2. **`Side_force[2]` is the biggest lever for drift speed.** A high value creates an enormous lateral push that forces a wide drift angle and generates huge drag.
3. **Nitrous recovery settings live globally in `GAMEPLAY.BNDL`.** Refill volume rates (drifting, oncoming, drafting, near-misses) can be scaled up (e.g. +28% / `1.28x`) and speed thresholds lowered to give a smooth, highly effective boost recovery that shaves massive seconds off lap times.
4. **Virtual downforce is a balance of drag and width.** By pairing low drag coefficients (`0.58`/`0.80`) with a restricted slide width (`0.85`) and shallower yaw (`0.98`), you achieve an F1-like "gliding" sensation that tracks the road smoothly.
