"""
toggle_slipstream.py — Toggle slipstream NOS refill on/off in NFS Hot Pursuit Remastered.

This script modifies the Slipstreaming sub-block inside every NitrousParameters
instance in GAMEPLAY.BNDL. It can:
  - DISABLE slipstream NOS refill by setting rate → 0.0 and minspeed → 9999.0
  - RESTORE slipstream NOS refill to your chosen profile (stock, subtle, OP, etc.)

Usage:
    python Scripts/toggle_slipstream.py                 # Auto-detect and toggle
    python Scripts/toggle_slipstream.py --disable       # Force disable slipstream
    python Scripts/toggle_slipstream.py --restore       # Force restore slipstream
    python Scripts/toggle_slipstream.py --restore --profile op65   # Restore with OP +65% values
    python Scripts/toggle_slipstream.py --status        # Show current state without changing

Profiles for --restore:
    stock   = Original game values (rate from .bak, minspeed 65 km/h)
    subtle  = +28% rate, minspeed 65 km/h
    op40    = +40% rate, minspeed 65 km/h
    op65    = +65% rate, minspeed 60 km/h  (default)
"""
import struct
import shutil
import subprocess
import argparse
from pathlib import Path

# ─── Paths ───────────────────────────────────────────────────────────────────
workspace_dir = Path(__file__).resolve().parent.parent
gameplay_unpack_dir = workspace_dir / "temp_slipstream_toggle_unpack"
gameplay_output_dir = workspace_dir / "temp_slipstream_toggle_output"
gamelogic_dir = Path(r"D:\Need For Speed Hot Pursuit Remastered\GAMELOGIC")

# NitrousParameters instance files that contain slipstream data
NITROUS_INSTANCE_FILES = [
    "11_46_06_00.dat",
    "9E_E9_09_00.dat",
    "9F_E9_09_00.dat",
    "A2_04_09_00.dat",
    "A3_04_09_00.dat",
    "FA_EA_03_00.dat",
]

# Slipstream pointer lives at offset 152 (0x98) in each NitrousParameters instance.
# The sub-block data starts at (pointer_value + 48).
# Within the sub-block:
#   +0x00  hash/ID  (4 bytes, always 0x00064637)
#   +0x04  minspeed (float, stock = 65.0 km/h)
#   +0x08  rate     (float, varies per instance: 2.8 to 5.6)
#   +0x0C  unknown  (4 bytes, always 0x00000001)
#   +0x10  bool     (1 byte, always 0x00)
SLIP_PTR_OFFSET = 152
SLIP_SUB_HEADER = 48
SLIP_MINSPEED_REL = 4
SLIP_RATE_REL = 8

# Disabled sentinel values
DISABLED_RATE = 0.0
DISABLED_MINSPEED = 9999.0

# Profile multipliers and speed thresholds for restoration
PROFILES = {
    "stock":  {"multiplier": 1.00, "minspeed": 65.0},
    "subtle": {"multiplier": 1.28, "minspeed": 65.0},
    "op40":   {"multiplier": 1.40, "minspeed": 65.0},
    "op65":   {"multiplier": 1.65, "minspeed": 60.0},
}


def get_f(data, offset):
    return struct.unpack_from("<f", data, offset)[0]


def set_f(data, offset, val):
    struct.pack_into("<f", data, offset, val)


def clean_temp():
    """Remove temporary unpack/output directories."""
    for d in [gameplay_unpack_dir, gameplay_output_dir]:
        if d.exists():
            shutil.rmtree(d, ignore_errors=True)


def unpack_gameplay(source_file):
    """Unpack a GAMEPLAY.BNDL into the temp directory."""
    clean_temp()
    gameplay_output_dir.mkdir(parents=True, exist_ok=True)
    cmd = [
        "python", "bundle_packer_unpacker.py",
        "-u", "hpr",
        str(source_file),
        str(gameplay_unpack_dir),
    ]
    res = subprocess.run(cmd, cwd=str(workspace_dir), capture_output=True, text=True)
    if res.returncode != 0:
        raise RuntimeError(f"Unpack failed: {res.stderr}")


def repack_gameplay():
    """Repack and patch the GAMEPLAY.BNDL, then install."""
    cmd = [
        "python", "bundle_packer_unpacker.py",
        "-p", "hpr",
        str(gameplay_unpack_dir / "IDs_GAMEPLAY.json"),
        str(gameplay_output_dir),
        "GAMEPLAY.BNDL",
    ]
    res = subprocess.run(cmd, cwd=str(workspace_dir), capture_output=True, text=True)
    if res.returncode != 0:
        raise RuntimeError(f"Repack failed: {res.stderr}")

    output_bin = gameplay_output_dir / "GAMEPLAY.BNDL"

    # Patch platform byte to PC (0x01)
    with open(output_bin, "r+b") as f:
        f.seek(8)
        if f.read(1)[0] != 0x01:
            f.seek(8)
            f.write(b"\x01")
            print("  Patched platform byte to 0x01.")

    # Install to game folder
    dest = gamelogic_dir / "GAMEPLAY.BNDL"
    shutil.copy2(output_bin, dest)
    print(f"  Installed modified GAMEPLAY.BNDL to game folder.")


def read_slipstream_state(instances_dir):
    """Read current slipstream values from all instance files. Returns list of dicts."""
    states = []
    for fn in NITROUS_INSTANCE_FILES:
        filepath = instances_dir / fn
        if not filepath.exists():
            continue
        data = bytearray(filepath.read_bytes())
        slip_ptr = struct.unpack_from("<I", data, SLIP_PTR_OFFSET)[0]
        sub_base = slip_ptr + SLIP_SUB_HEADER
        rate_offset = sub_base + SLIP_RATE_REL
        minspeed_offset = sub_base + SLIP_MINSPEED_REL
        rate = get_f(data, rate_offset)
        minspeed = get_f(data, minspeed_offset)
        states.append({
            "file": fn,
            "rate": rate,
            "minspeed": minspeed,
            "rate_offset": rate_offset,
            "minspeed_offset": minspeed_offset,
        })
    return states


def is_disabled(states):
    """Check if slipstream is currently disabled (all rates are 0.0)."""
    return all(s["rate"] == 0.0 for s in states)


def read_stock_rates():
    """Read the stock slipstream rates from the .bak backup or GameplayBackups stock file."""
    backup = gamelogic_dir / "GAMEPLAY.BNDL.bak"
    if not backup.exists():
        # Fall back to the local stock backup in GameplayBackups/
        backup = workspace_dir / "GameplayBackups" / "GAMEPLAY_STOCK.BNDL"
    if not backup.exists():
        raise FileNotFoundError(
            "Neither GAMEPLAY.BNDL.bak nor GameplayBackups/GAMEPLAY_STOCK.BNDL found!"
        )
    # Temporarily unpack the backup to read stock values
    temp_stock_dir = workspace_dir / "temp_slipstream_stock_read"
    if temp_stock_dir.exists():
        shutil.rmtree(temp_stock_dir, ignore_errors=True)
    cmd = [
        "python", "bundle_packer_unpacker.py",
        "-u", "hpr",
        str(backup),
        str(temp_stock_dir),
    ]
    res = subprocess.run(cmd, cwd=str(workspace_dir), capture_output=True, text=True)
    if res.returncode != 0:
        raise RuntimeError(f"Stock unpack failed: {res.stderr}")

    stock_rates = {}
    inst_dir = temp_stock_dir / "GenesysInstance"
    for fn in NITROUS_INSTANCE_FILES:
        filepath = inst_dir / fn
        if not filepath.exists():
            continue
        data = bytearray(filepath.read_bytes())
        slip_ptr = struct.unpack_from("<I", data, SLIP_PTR_OFFSET)[0]
        sub_base = slip_ptr + SLIP_SUB_HEADER
        stock_rates[fn] = get_f(data, sub_base + SLIP_RATE_REL)

    shutil.rmtree(temp_stock_dir, ignore_errors=True)
    return stock_rates


def disable_slipstream():
    """Disable slipstream NOS refill by zeroing rates and setting impossibly high minspeed."""
    game_file = gamelogic_dir / "GAMEPLAY.BNDL"
    if not game_file.exists():
        print("ERROR: GAMEPLAY.BNDL not found in game folder!")
        return

    print("Unpacking current GAMEPLAY.BNDL...")
    unpack_gameplay(game_file)

    instances_dir = gameplay_unpack_dir / "GenesysInstance"
    states = read_slipstream_state(instances_dir)

    if is_disabled(states):
        print("\n  Slipstream is ALREADY DISABLED. No changes needed.")
        clean_temp()
        return

    print("\nDisabling slipstream NOS refill across all NitrousParameters instances:")
    for fn in NITROUS_INSTANCE_FILES:
        filepath = instances_dir / fn
        if not filepath.exists():
            continue
        data = bytearray(filepath.read_bytes())
        slip_ptr = struct.unpack_from("<I", data, SLIP_PTR_OFFSET)[0]
        sub_base = slip_ptr + SLIP_SUB_HEADER

        old_rate = get_f(data, sub_base + SLIP_RATE_REL)
        old_minspeed = get_f(data, sub_base + SLIP_MINSPEED_REL)

        set_f(data, sub_base + SLIP_RATE_REL, DISABLED_RATE)
        set_f(data, sub_base + SLIP_MINSPEED_REL, DISABLED_MINSPEED)

        filepath.write_bytes(data)
        print(f"  {fn}: rate {old_rate:g} -> {DISABLED_RATE:g} | minspeed {old_minspeed:g} -> {DISABLED_MINSPEED:g}")

    print("\nRepacking and installing...")
    repack_gameplay()
    clean_temp()
    print("\n[OK] SLIPSTREAM NOS REFILL DISABLED. Restart the game to apply.")


def restore_slipstream(profile_name="op65"):
    """Restore slipstream NOS refill values from stock backup, scaled by the chosen profile."""
    profile = PROFILES.get(profile_name)
    if not profile:
        print(f"ERROR: Unknown profile '{profile_name}'. Options: {', '.join(PROFILES.keys())}")
        return

    print("Reading stock slipstream rates...")
    try:
        stock_rates = read_stock_rates()
    except FileNotFoundError as e:
        print(f"ERROR: {e}")
        return

    # Use .bak if available, otherwise fall back to GameplayBackups stock
    backup = gamelogic_dir / "GAMEPLAY.BNDL.bak"
    if not backup.exists():
        backup = workspace_dir / "GameplayBackups" / "GAMEPLAY_STOCK.BNDL"
    if not backup.exists():
        print("ERROR: No stock backup found to restore from!")
        return
    print(f"Unpacking stock GAMEPLAY.BNDL from {backup.name}...")
    unpack_gameplay(backup)

    instances_dir = gameplay_unpack_dir / "GenesysInstance"

    multiplier = profile["multiplier"]
    target_minspeed = profile["minspeed"]

    print(f"\nRestoring slipstream NOS refill (profile: {profile_name}, {multiplier:.0%} rate, minspeed {target_minspeed:g} km/h):")
    for fn in NITROUS_INSTANCE_FILES:
        filepath = instances_dir / fn
        if not filepath.exists():
            continue
        data = bytearray(filepath.read_bytes())
        slip_ptr = struct.unpack_from("<I", data, SLIP_PTR_OFFSET)[0]
        sub_base = slip_ptr + SLIP_SUB_HEADER

        base_rate = stock_rates.get(fn, 2.8)
        new_rate = base_rate * multiplier

        set_f(data, sub_base + SLIP_RATE_REL, new_rate)
        set_f(data, sub_base + SLIP_MINSPEED_REL, target_minspeed)

        # If restoring from stock backup, also apply the other NOS buffs
        # for consistency with the chosen profile (drift, oncoming, nearmiss)
        drift_ptr = struct.unpack_from("<I", data, 80)[0]
        oncoming_ptr = struct.unpack_from("<I", data, 96)[0]
        nearmiss_ptr = struct.unpack_from("<I", data, 88)[0]

        # Apply profile multiplier to other NOS sources too
        if profile_name != "stock":
            # Drifting
            dr_rate_off = drift_ptr + 48 + 4
            old_dr = get_f(data, dr_rate_off)
            set_f(data, dr_rate_off, old_dr * multiplier)
            if profile_name == "op65":
                set_f(data, drift_ptr + 48 + 8, 45.0)
            else:
                set_f(data, drift_ptr + 48 + 8, 47.0)

            # Oncoming
            oc_rate_off = oncoming_ptr + 48 + 8
            set_f(data, oc_rate_off, multiplier)
            if profile_name == "op65":
                set_f(data, oncoming_ptr + 48 + 4, 85.0)
            else:
                set_f(data, oncoming_ptr + 48 + 4, 90.0)

            # Near miss
            nm_rate_off = nearmiss_ptr + 48 + 8
            old_nm = get_f(data, nm_rate_off)
            set_f(data, nm_rate_off, old_nm * multiplier)
            if profile_name == "op65":
                set_f(data, nearmiss_ptr + 48 + 4, 50.0)
            else:
                set_f(data, nearmiss_ptr + 48 + 4, 52.0)

        filepath.write_bytes(data)
        print(f"  {fn}: rate -> {new_rate:g} | minspeed -> {target_minspeed:g}")

    print("\nRepacking and installing...")
    repack_gameplay()
    clean_temp()
    print(f"\n[OK] SLIPSTREAM NOS REFILL RESTORED ({profile_name} profile). Restart the game to apply.")


def show_status():
    """Show the current slipstream state without modifying anything."""
    game_file = gamelogic_dir / "GAMEPLAY.BNDL"
    if not game_file.exists():
        print("ERROR: GAMEPLAY.BNDL not found in game folder!")
        return

    print("Reading current GAMEPLAY.BNDL...")
    unpack_gameplay(game_file)

    instances_dir = gameplay_unpack_dir / "GenesysInstance"
    states = read_slipstream_state(instances_dir)

    disabled = is_disabled(states)
    status = "DISABLED" if disabled else "ENABLED"
    print(f"\n  Slipstream NOS Refill: {status}")
    print(f"  {'-' * 60}")
    for s in states:
        print(f"  {s['file']:>20s}  rate={s['rate']:8.3f}  minspeed={s['minspeed']:8.1f}")

    clean_temp()


def main():
    parser = argparse.ArgumentParser(
        description="Toggle slipstream NOS refill in NFS Hot Pursuit Remastered"
    )
    group = parser.add_mutually_exclusive_group()
    group.add_argument("--disable", action="store_true",
                       help="Disable slipstream NOS refill")
    group.add_argument("--restore", action="store_true",
                       help="Restore slipstream NOS refill")
    group.add_argument("--status", action="store_true",
                       help="Show current slipstream state")
    parser.add_argument("--profile", default="op65",
                        choices=list(PROFILES.keys()),
                        help="NOS buff profile to use when restoring (default: op65)")
    args = parser.parse_args()

    if args.status:
        show_status()
    elif args.disable:
        disable_slipstream()
    elif args.restore:
        restore_slipstream(args.profile)
    else:
        # Auto-detect: if currently enabled, disable. If disabled, restore.
        print("Auto-detecting current slipstream state...")
        game_file = gamelogic_dir / "GAMEPLAY.BNDL"
        if not game_file.exists():
            print("ERROR: GAMEPLAY.BNDL not found!")
            return

        unpack_gameplay(game_file)
        instances_dir = gameplay_unpack_dir / "GenesysInstance"
        states = read_slipstream_state(instances_dir)
        clean_temp()

        if is_disabled(states):
            print("  Currently: DISABLED → Restoring...\n")
            restore_slipstream(args.profile)
        else:
            print("  Currently: ENABLED → Disabling...\n")
            disable_slipstream()


if __name__ == "__main__":
    main()
