import struct
import os
import shutil

filepath = 'Viper/MS/GenesysInstance/6B_A3_02_00.dat'

# 1. Ensure a clean backup of the unpacked file exists before modifying
if not os.path.exists(filepath + '.bak'):
    shutil.copy2(filepath, filepath + '.bak')

# 2. Modify the file
with open(filepath, 'rb') as f:
    data = bytearray(f.read())

# Change Drift_exit threshold (offset 0x240) to 3.8
# Stock was 5.0, previous was 3.5
struct.pack_into('<f', data, 0x240, 4.0)

with open(filepath, 'wb') as f:
    f.write(data)

print("Successfully written 4.0 to offset 0x240 in 6B_A3_02_00.dat")
