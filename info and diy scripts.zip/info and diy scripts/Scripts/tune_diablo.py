import struct
import shutil
import os
import subprocess
from pathlib import Path

# Paths
workspace_dir = Path(__file__).resolve().parent.parent
diablo_dir = workspace_dir / "Cars" / "Diablo"
output_dir = diablo_dir / "diablo_slight_buffed"

def set_f(data, offset, val):
    struct.pack_into("<f", data, offset, val)

def get_f(data, offset):
    return struct.unpack_from("<f", data, offset)[0]

def main():
    output_dir.mkdir(parents=True, exist_ok=True)
    print(f"Target output directory: {output_dir}\n")

    # 1. Modify and repack the MS stream files for both variants
    variants = [
        ("unpacked_1111287", "IDs_VEH_1111287_MS.json", "VEH_1111287_MS.BIN"),
        ("unpacked_1111611", "IDs_VEH_1111611_MS.json", "VEH_1111611_MS.BIN"),
    ]

    for unpacked_folder, json_name, bin_name in variants:
        unpacked_path = diablo_dir / unpacked_folder
        drift_file = unpacked_path / "GenesysInstance" / "13_F5_10_00.dat"

        if not drift_file.exists():
            print(f"Error: DriftBehaviour file not found at {drift_file}")
            continue

        # Modify drift exit value to 4.0
        dr_data = bytearray(drift_file.read_bytes())
        old_val = get_f(dr_data, 0x240)
        set_f(dr_data, 0x240, 4.0)
        drift_file.write_bytes(dr_data)
        print(f"Modified drift exit for {unpacked_folder} (13_F5_10_00.dat):")
        print(f"  Drift exit delay (0x240): {old_val} -> 4.0")

        # Repack the bundle
        print(f"Repacking modified files into {bin_name}...")
        cmd_pack = [
            "python", 
            "bundle_packer_unpacker.py", 
            "-p", "hpr", 
            str(unpacked_path / json_name), 
            str(output_dir), 
            bin_name
        ]
        res_pack = subprocess.run(cmd_pack, cwd=str(workspace_dir), capture_output=True, text=True)
        if res_pack.returncode != 0:
            print(f"Failed to repack {bin_name}! Error:\n{res_pack.stderr}")
            continue
        print(f"Repacked {bin_name} successfully.")

        # Verify platform byte is 0x01
        repacked_bin = output_dir / bin_name
        with open(repacked_bin, "r+b") as f:
            f.seek(8)
            pb = f.read(1)[0]
            if pb != 0x01:
                f.seek(8)
                f.write(b"\x01")
                print(f"Patched platform byte of {bin_name} back to 0x01.")
            else:
                print(f"Platform byte of {bin_name} is correct (0x01).")
        print()

    # 2. Copy the EN / ENCMP files from stock to output directory
    print("Copying audio stream files to output folder...")
    for filename in ["VEH_1111287_EN.BIN", "VEH_1111287_ENCMP.BIN"]:
        src_file = diablo_dir / filename
        if src_file.exists():
            shutil.copy2(src_file, output_dir / filename)
            print(f"  Copied {filename}")
        else:
            print(f"  Source audio file {filename} not found in {diablo_dir}")

    print("\nSUCCESS: All files repacked and prepared in diablo_slight_buffed!")

if __name__ == "__main__":
    main()
