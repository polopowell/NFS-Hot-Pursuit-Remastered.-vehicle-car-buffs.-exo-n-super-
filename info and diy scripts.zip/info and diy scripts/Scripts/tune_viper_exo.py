import struct
import shutil
import os
import subprocess
from pathlib import Path

# Paths
base_dir = Path(r"C:\Users\xboxF\Documents\stuff\handling_tools")
stock_dir = base_dir / "Viper" / "stockviper"
exo_dir = base_dir / "Viper" / "viper_exo"
unpacked_dir = base_dir / "Viper" / "stockviper-unpacked"
inst_dir = unpacked_dir / "MS" / "GenesysInstance"

src_bin = stock_dir / "VEH_172882_MS.BIN"
dest_bin = exo_dir / "VEH_172882_MS.BIN"

def set_f(data, offset, val):
    struct.pack_into("<f", data, offset, val)

def get_f(data, offset):
    return struct.unpack_from("<f", data, offset)[0]

def main():
    # Ensure exo_dir exists
    exo_dir.mkdir(parents=True, exist_ok=True)

    # 1. Unpack stock MS.BIN to stockviper-unpacked
    if unpacked_dir.exists():
        shutil.rmtree(unpacked_dir)
    unpacked_dir.mkdir(parents=True, exist_ok=True)

    print("Unpacking stock Viper stream bundle...")
    cmd_unpack = [
        "python", 
        "bundle_packer_unpacker.py", 
        "-u", "hpr", 
        str(src_bin), 
        str(unpacked_dir / "MS")
    ]
    res_unpack = subprocess.run(cmd_unpack, cwd=str(base_dir), capture_output=True, text=True)
    if res_unpack.returncode != 0:
        print(f"Failed to unpack! Error:\n{res_unpack.stderr}")
        return

    print("Unpacked successfully.")

    # 2. Modify DriftBehaviour: set Drift_exit[0] (0x240) to 3.5
    drift_file = inst_dir / "6B_A3_02_00.dat"
    if drift_file.exists():
        dr_data = bytearray(drift_file.read_bytes())
        old_exit = get_f(dr_data, 0x240)
        set_f(dr_data, 0x240, 3.5)
        drift_file.write_bytes(dr_data)
        print(f"\nModified DriftBehaviour (6B_A3_02_00.dat):")
        print(f"  Drift exit threshold (0x240): {old_exit} -> 3.5 (Tuned)")
    else:
        print(f"Error: DriftBehaviour file not found at {drift_file}")
        return

    # 3. Repack modified files to exo_dir/VEH_172882_MS.BIN
    print("\nRepacking modified files into exo variant...")
    cmd_pack = [
        "python", 
        "bundle_packer_unpacker.py", 
        "-p", "hpr", 
        str(unpacked_dir / "MS" / "IDs_VEH_172882_MS.json"), 
        str(exo_dir), 
        "VEH_172882_MS.BIN"
    ]
    res_pack = subprocess.run(cmd_pack, cwd=str(base_dir), capture_output=True, text=True)
    if res_pack.returncode != 0:
        print(f"Failed to repack! Error:\n{res_pack.stderr}")
        return

    print("Repacked successfully.")

    # 4. Verify platform byte (ensure 0x01)
    with open(dest_bin, "r+b") as f:
        f.seek(8)
        pb = f.read(1)[0]
        if pb != 0x01:
            f.seek(8)
            f.write(b"\x01")
            print("Patched platform byte of repacked BIN back to 0x01.")
        else:
            print("Platform byte is correct (0x01).")

    # 5. Copy stock engine audio files to exo_dir
    print("\nCopying engine and audio stream binaries from stockviper...")
    for filename in ["VEH_172882_EN.BIN", "VEH_172882_ENCMP.BIN"]:
        src_file = stock_dir / filename
        dest_file = exo_dir / filename
        shutil.copy2(src_file, dest_file)
        print(f"  Copied {filename} to viper_exo")

    print("\nVariant creation complete! All files ready in viper_exo.")

if __name__ == "__main__":
    main()
