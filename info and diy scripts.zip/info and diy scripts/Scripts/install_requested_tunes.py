import shutil
import os
from pathlib import Path

# Paths
workspace_dir = Path(__file__).resolve().parent.parent
game_vehicles = Path(r"D:\Need For Speed Hot Pursuit Remastered\VEHICLES")

# List of tuples: (source_path, target_filename)
tunes_to_install = [
    # SL65
    (workspace_dir / "Cars" / "SL65" / "VEH_329012_MS.BIN", "VEH_329012_MS.BIN"),
    (workspace_dir / "Cars" / "SL65" / "VEH_329012_EN.BIN", "VEH_329012_EN.BIN"),
    (workspace_dir / "Cars" / "SL65" / "VEH_329012_ENCMP.BIN", "VEH_329012_ENCMP.BIN"),
    
    # Zonda Cinque NFS
    (workspace_dir / "Cars" / "Zonda.BNDL", "VEH_745251_MS.BIN"),
    
    # Zonda Cinque (Regular)
    (workspace_dir / "Cars" / "Zonda" / "cinque-non-NFS-stockworks" / "VEH_380630_MS.BIN", "VEH_380630_MS.BIN"),
    
    # Zonda R
    (workspace_dir / "Cars" / "ZondaR.BNDL", "VEH_745296_MS.BIN"),
]

def main():
    print("Starting installation of tuned vehicle files...")
    print(f"Target game directory: {game_vehicles}\n")

    if not game_vehicles.exists():
        print(f"Error: Game vehicles directory '{game_vehicles}' does not exist.")
        return

    success_count = 0
    for src_path, filename in tunes_to_install:
        if not src_path.exists():
            print(f"Error: Source file '{src_path}' not found. Skipping {filename}.")
            continue

        dest_file = game_vehicles / filename
        bak_file = game_vehicles / f"{filename}.bak"

        # 1. Back up original game file if backup does not already exist
        try:
            if dest_file.exists() and not bak_file.exists():
                shutil.copy2(dest_file, bak_file)
                print(f"  [Backup] Created backup of stock game file: {bak_file.name}")
            elif dest_file.exists():
                print(f"  [Backup] Backup already exists for {filename}: {bak_file.name}")
        except Exception as e:
            print(f"  [Backup Error] Failed to backup {filename}: {e}")
            continue

        # 2. Copy the tuned file to the game directory
        try:
            shutil.copy2(src_path, dest_file)
            print(f"  [Installed] Copied {src_path.name} -> {filename}")
            success_count += 1
        except Exception as e:
            print(f"  [Install Error] Failed to install {filename}: {e}")

    print(f"\nInstallation complete. Successfully installed {success_count}/{len(tunes_to_install)} files.")

if __name__ == "__main__":
    main()
