import struct
import shutil
import os
import subprocess
from pathlib import Path

# Paths
workspace_dir = Path(__file__).resolve().parent.parent
pre_buff_dir = workspace_dir / "Cars" / "Viper" / "main tune-pre-buff"
test2_5_dir = pre_buff_dir / "test 2.5"
temp_dir = workspace_dir / "Cars" / "Viper" / "rebuild-temp-test2.5"
inst_dir = temp_dir / "MS" / "GenesysInstance"

def set_f(data, offset, val):
    struct.pack_into("<f", data, offset, val)

def get_f(data, offset):
    return struct.unpack_from("<f", data, offset)[0]

def main():
    # Make sure output directory exists
    test2_5_dir.mkdir(parents=True, exist_ok=True)

    # 1. Check backup of stock pre-buff MS.BIN
    backup_bin = pre_buff_dir / "VEH_172882_MS.BIN.bak"
    if not backup_bin.exists():
        shutil.copy2(pre_buff_dir / "VEH_172882_MS.BIN", backup_bin)
        print("Created backup of stock pre-buff MS.BIN.")

    # 2. Clean/Create rebuild temporary folder
    if temp_dir.exists():
        shutil.rmtree(temp_dir, ignore_errors=True)
    temp_dir.mkdir(parents=True, exist_ok=True)
    
    shutil.copy2(backup_bin, temp_dir / "VEH_172882_MS.BIN")

    # 3. Unpack the stock pre-buff BIN
    print("Unpacking stock pre-buff stream file...")
    cmd_unpack = [
        "python", 
        "bundle_packer_unpacker.py", 
        "-u", "hpr", 
        str(temp_dir / "VEH_172882_MS.BIN"), 
        str(temp_dir / "MS")
    ]
    res_unpack = subprocess.run(cmd_unpack, cwd=str(workspace_dir), capture_output=True, text=True)
    if res_unpack.returncode != 0:
        print(f"Failed to unpack! Error:\n{res_unpack.stderr}")
        return
    print("Unpacked successfully.")

    # 4. Modify Drift Behaviour (Same as test 2 / test 3)
    drift_file = inst_dir / "6B_A3_02_00.dat"
    if drift_file.exists():
        dr_data = bytearray(drift_file.read_bytes())
        
        # Apply edits
        set_f(dr_data, 0xD0, 0.58)          # Speed retention (0.58)
        set_f(dr_data, 0xD4, 0.98)          # Shallow glide yaw
        set_f(dr_data, 0xD8, 0.85)          # Reduced slide width
        set_f(dr_data, 0x188, 0.80)         # Lateral drag
        set_f(dr_data, 0x240, 2.90)         # Drift exit delay (2.9)
        
        drift_file.write_bytes(dr_data)
        print("\nApplied Drift Behaviour modifications for Test 2.5.")
    else:
        print(f"Error: DriftBehaviour file not found at {drift_file}")
        return

    # 5. Modify Engine block (For Test 2.5 - sitting exactly between Test 2 and Test 3)
    engine_file = inst_dir / "6F_A3_02_00.dat"
    if engine_file.exists():
        eng_data = bytearray(engine_file.read_bytes())
        
        old_gov = get_f(eng_data, 176)
        old_nos = get_f(eng_data, 264)
        old_base = get_f(eng_data, 268)
        old_peak = get_f(eng_data, 272)
        
        # Apply edits (Tune 2.5: nerf relative to Tune 3, sitting halfway between 2 and 3)
        # Stock: gov=202.0, nos=600.0, base=720.0, peak=800.0
        # Tune 3: gov=205.0, nos=800.0, base=770.0, peak=860.0
        set_f(eng_data, 176, 203.5)         # Governor: 203.5 m/s (+5.4 km/h)
        set_f(eng_data, 264, 700.0)         # NOS HP: 700.0 HP
        set_f(eng_data, 268, 745.0)         # Base Torque: 745.0
        set_f(eng_data, 272, 830.0)         # Peak Torque: 830.0
        
        engine_file.write_bytes(eng_data)
        print("\nApplied Engine modifications for Test 2.5:")
        print(f"  Max Speed Governor (offset 176): {old_gov:g} -> 203.5 m/s")
        print(f"  NOS Horsepower (offset 264): {old_nos:g} -> 700 HP")
        print(f"  Base Torque (offset 268): {old_base:g} -> 745")
        print(f"  Peak Torque (offset 272): {old_peak:g} -> 830")
    else:
        print(f"Error: Engine file not found at {engine_file}")
        return

    # 6. Repack the bundle
    print("\nRepacking modified files into VEH_172882_MS.BIN...")
    cmd_pack = [
        "python", 
        "bundle_packer_unpacker.py", 
        "-p", "hpr", 
        str(temp_dir / "MS" / "IDs_VEH_172882_MS.json"), 
        str(test2_5_dir), 
        "VEH_172882_MS.BIN"
    ]
    res_pack = subprocess.run(cmd_pack, cwd=str(workspace_dir), capture_output=True, text=True)
    if res_pack.returncode != 0:
        print(f"Failed to repack! Error:\n{res_pack.stderr}")
        return
    print("Repacked successfully.")

    # 7. Verify platform byte (ensure 0x01)
    repacked_bin = test2_5_dir / "VEH_172882_MS.BIN"
    with open(repacked_bin, "r+b") as f:
        f.seek(8)
        pb = f.read(1)[0]
        if pb != 0x01:
            f.seek(8)
            f.write(b"\x01")
            print("Patched platform byte of repacked BIN back to 0x01.")
        else:
            print("Platform byte is correct (0x01).")

    # 8. Copy audio streams to the test 2.5 folder
    print("\nCopying audio streams to test 2.5 folder...")
    for filename in ["VEH_172882_EN.BIN", "VEH_172882_ENCMP.BIN"]:
        shutil.copy2(pre_buff_dir / filename, test2_5_dir / filename)
        print(f"  Copied {filename}")

    # 9. Clean up rebuild temp folder
    shutil.rmtree(temp_dir, ignore_errors=True)
    print("\nCleaned up rebuild temporary folder.")

    print(f"\nSUCCESS: Created 'test 2.5' balanced variant in {test2_5_dir}!")

if __name__ == "__main__":
    main()
