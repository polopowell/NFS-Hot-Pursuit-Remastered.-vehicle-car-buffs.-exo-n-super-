import struct
import shutil
import os
import subprocess
from pathlib import Path

# Paths
workspace_dir = Path(__file__).resolve().parent.parent
pre_buff_dir = workspace_dir / "Cars" / "Viper" / "main tune-pre-buff"
test0_dir = pre_buff_dir / "test 0"
temp_dir = workspace_dir / "Cars" / "Viper" / "rebuild-temp-test0"
inst_dir = temp_dir / "MS" / "GenesysInstance"

def set_f(data, offset, val):
    struct.pack_into("<f", data, offset, val)

def get_f(data, offset):
    return struct.unpack_from("<f", data, offset)[0]

def main():
    # Make sure output directory exists
    test0_dir.mkdir(parents=True, exist_ok=True)

    # 1. Check backup of stock pre-buff MS.BIN
    backup_bin = pre_buff_dir / "VEH_172882_MS.BIN.bak"
    if not backup_bin.exists():
        shutil.copy2(pre_buff_dir / "VEH_172882_MS.BIN", backup_bin)
        print("Created backup of stock pre-buff MS.BIN.")

    # 2. Clean/Create rebuild temporary folder
    if temp_dir.exists():
        shutil.rmtree(temp_dir, ignore_errors=True)
    temp_dir.mkdir(parents=True, exist_ok=True)
    
    shutil.copy2(backup_bin, temp_dir / "VEH_172882_MS.BIN")

    # 3. Unpack the stock pre-buff BIN
    print("Unpacking stock pre-buff stream file...")
    cmd_unpack = [
        "python", 
        "bundle_packer_unpacker.py", 
        "-u", "hpr", 
        str(temp_dir / "VEH_172882_MS.BIN"), 
        str(temp_dir / "MS")
    ]
    res_unpack = subprocess.run(cmd_unpack, cwd=str(workspace_dir), capture_output=True, text=True)
    if res_unpack.returncode != 0:
        print(f"Failed to unpack! Error:\n{res_unpack.stderr}")
        return
    print("Unpacked successfully.")

    # 4. Modify Drift Behaviour (Same composed F1 glide chassis as Test 3 / Test 2)
    drift_file = inst_dir / "6B_A3_02_00.dat"
    if drift_file.exists():
        dr_data = bytearray(drift_file.read_bytes())
        
        old_drag = get_f(dr_data, 0xD0)
        old_yaw_amp = get_f(dr_data, 0xD4)
        old_slide_width = get_f(dr_data, 0xD8)
        old_lat = get_f(dr_data, 0x188)
        old_exit = get_f(dr_data, 0x240)
        
        # Apply edits
        set_f(dr_data, 0xD0, 0.58)          # Speed retention (0.58)
        set_f(dr_data, 0xD4, 0.98)          # Shallow glide yaw
        set_f(dr_data, 0xD8, 0.85)          # Reduced slide width
        set_f(dr_data, 0x188, 0.80)         # Lateral drag
        set_f(dr_data, 0x240, 2.90)         # Drift exit delay
        
        drift_file.write_bytes(dr_data)
        print("\nApplied Drift Behaviour modifications for Test 0:")
        print(f"  Drift drag multiplier (0xD0): {old_drag} -> 0.58")
        print(f"  Yaw force amplification (0xD4): {old_yaw_amp} -> 0.98")
        print(f"  Slide width (0xD8): {old_slide_width} -> 0.85")
        print(f"  Lateral drag (0x188): {old_lat} -> 0.80")
        print(f"  Drift exit delay (0x240): {old_exit} -> 2.90")
    else:
        print(f"Error: DriftBehaviour file not found at {drift_file}")
        return

    # NOTE: Engine file (6F_A3_02_00.dat) is NOT modified, keeping power, torque, NOS, and speed governor 100% stock.

    # 5. Repack the bundle
    print("\nRepacking modified files into VEH_172882_MS.BIN...")
    cmd_pack = [
        "python", 
        "bundle_packer_unpacker.py", 
        "-p", "hpr", 
        str(temp_dir / "MS" / "IDs_VEH_172882_MS.json"), 
        str(test0_dir), 
        "VEH_172882_MS.BIN"
    ]
    res_pack = subprocess.run(cmd_pack, cwd=str(workspace_dir), capture_output=True, text=True)
    if res_pack.returncode != 0:
        print(f"Failed to repack! Error:\n{res_pack.stderr}")
        return
    print("Repacked successfully.")

    # 6. Verify platform byte (ensure 0x01)
    repacked_bin = test0_dir / "VEH_172882_MS.BIN"
    with open(repacked_bin, "r+b") as f:
        f.seek(8)
        pb = f.read(1)[0]
        if pb != 0x01:
            f.seek(8)
            f.write(b"\x01")
            print("Patched platform byte of repacked BIN back to 0x01.")
        else:
            print("Platform byte is correct (0x01).")

    # 7. Copy audio streams to the test 0 folder
    print("\nCopying audio streams to test 0 folder...")
    for filename in ["VEH_172882_EN.BIN", "VEH_172882_ENCMP.BIN"]:
        shutil.copy2(pre_buff_dir / filename, test0_dir / filename)
        print(f"  Copied {filename}")

    # 8. Clean up rebuild temp folder
    shutil.rmtree(temp_dir, ignore_errors=True)
    print("\nCleaned up rebuild temporary folder.")

    print(f"\nSUCCESS: Created 'test 0' tune variant (Composed Chassis / Stock Power) in {test0_dir}!")

if __name__ == "__main__":
    main()
