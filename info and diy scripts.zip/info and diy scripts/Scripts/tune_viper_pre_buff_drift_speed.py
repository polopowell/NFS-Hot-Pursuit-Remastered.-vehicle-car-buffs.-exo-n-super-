import struct
import shutil
import os
import subprocess
from pathlib import Path

# Paths
workspace_dir = Path(__file__).resolve().parent.parent
pre_buff_dir = workspace_dir / "Cars" / "Viper" / "main tune-pre-buff"
temp_dir = workspace_dir / "Cars" / "Viper" / "rebuild-temp-prebuff-speed"
inst_dir = temp_dir / "MS" / "GenesysInstance"

def set_f(data, offset, val):
    struct.pack_into("<f", data, offset, val)

def get_f(data, offset):
    return struct.unpack_from("<f", data, offset)[0]

def main():
    # 1. Restore stock MS.BIN from backup to apply modifications freshly
    original_bin = pre_buff_dir / "VEH_172882_MS.BIN"
    backup_bin = pre_buff_dir / "VEH_172882_MS.BIN.bak"
    
    if not backup_bin.exists():
        shutil.copy2(original_bin, backup_bin)
        print("Created backup of original main tune-pre-buff MS.BIN.")
    else:
        print("Restoring main tune-pre-buff MS.BIN from stock backup.")
        shutil.copy2(backup_bin, original_bin)

    # 2. Clean/Create rebuild temporary folder
    if temp_dir.exists():
        shutil.rmtree(temp_dir, ignore_errors=True)
    temp_dir.mkdir(parents=True, exist_ok=True)
    
    shutil.copy2(original_bin, temp_dir / "VEH_172882_MS.BIN")

    # 3. Unpack the MS.BIN
    print("Unpacking stream file...")
    cmd_unpack = [
        "python", 
        "bundle_packer_unpacker.py", 
        "-u", "hpr", 
        str(temp_dir / "VEH_172882_MS.BIN"), 
        str(temp_dir / "MS")
    ]
    res_unpack = subprocess.run(cmd_unpack, cwd=str(workspace_dir), capture_output=True, text=True)
    if res_unpack.returncode != 0:
        print(f"Failed to unpack! Error:\n{res_unpack.stderr}")
        return
    print("Unpacked successfully.")

    # 4. Modify Drift Behaviour values back to the 'test' settings (0.58 drag, 1.02 yaw, 0.80 lat force, 3.2 exit delay)
    drift_file = inst_dir / "6B_A3_02_00.dat"
    if drift_file.exists():
        dr_data = bytearray(drift_file.read_bytes())
        
        old_drag = get_f(dr_data, 0xD0)
        old_yaw_amp = get_f(dr_data, 0xD4)
        old_lat = get_f(dr_data, 0x188)
        old_exit = get_f(dr_data, 0x240)
        
        # Apply edits
        set_f(dr_data, 0xD0, 0.58)      # Reduced drift drag
        set_f(dr_data, 0xD4, 1.02)      # Yaw force amp back to 1.02 (user preferred)
        set_f(dr_data, 0x188, 0.80)     # Reduced lateral force drag
        set_f(dr_data, 0x240, 3.20)      # Drift exit delay back to 3.2 (user preferred)
        
        drift_file.write_bytes(dr_data)
        print("\nApplied Drift Behaviour modifications:")
        print(f"  Drift drag multiplier (0xD0): {old_drag} -> 0.58")
        print(f"  Yaw force amplification (0xD4): {old_yaw_amp} -> 1.02")
        print(f"  Lateral drag (0x188): {old_lat} -> 0.80")
        print(f"  Drift exit delay (0x240): {old_exit} -> 3.20")
    else:
        print(f"Error: DriftBehaviour file not found at {drift_file}")
        return

    # 5. Repack the bundle
    print("\nRepacking modified files into VEH_172882_MS.BIN...")
    cmd_pack = [
        "python", 
        "bundle_packer_unpacker.py", 
        "-p", "hpr", 
        str(temp_dir / "MS" / "IDs_VEH_172882_MS.json"), 
        str(pre_buff_dir), 
        "VEH_172882_MS.BIN"
    ]
    res_pack = subprocess.run(cmd_pack, cwd=str(workspace_dir), capture_output=True, text=True)
    if res_pack.returncode != 0:
        print(f"Failed to repack! Error:\n{res_pack.stderr}")
        return
    print("Repacked successfully.")

    # 6. Verify platform byte (ensure 0x01)
    repacked_bin = pre_buff_dir / "VEH_172882_MS.BIN"
    with open(repacked_bin, "r+b") as f:
        f.seek(8)
        pb = f.read(1)[0]
        if pb != 0x01:
            f.seek(8)
            f.write(b"\x01")
            print("Patched platform byte of repacked BIN back to 0x01.")
        else:
            print("Platform byte is correct (0x01).")

    # 7. Clean up rebuild temp folder
    shutil.rmtree(temp_dir, ignore_errors=True)
    print("\nCleaned up rebuild temporary folder.")

    print(f"\nSUCCESS: Restored pre-buff tune to the preferred 'test' settings in place at {pre_buff_dir}!")

if __name__ == "__main__":
    main()
