import shutil
import os
import subprocess
from pathlib import Path

# Paths
base_dir = Path(r"C:\Users\xboxF\Documents\stuff\handling_tools")
zonda_dir = base_dir / "Zonda"
cinque_nfs_drift_file = zonda_dir / "MS" / "GenesysInstance" / "F1_CE_05_00.dat"

stockworks_dir = zonda_dir / "cinque-non-NFS-stockworks"
src_bin = stockworks_dir / "VEH_380630_MS.BIN"
bak_bin = stockworks_dir / "VEH_380630_MS.BIN.bak"

unpacked_dir = zonda_dir / "unpacked_380630"
dest_drift_file = unpacked_dir / "MS" / "GenesysInstance" / "F1_CE_05_00.dat"

def main():
    # 1. Back up original regular Zonda MS.BIN
    if src_bin.exists() and not bak_bin.exists():
        shutil.copy2(src_bin, bak_bin)
        print(f"Backed up original regular Zonda MS.BIN to {bak_bin.name}")

    # 2. Copy the tuned drift behaviour file from Cinque to the unpacked regular Zonda
    if dest_drift_file.exists():
        # Backup the stock drift file inside unpacked folder just in case
        dest_drift_bak = dest_drift_file.with_suffix(".dat.bak")
        if not dest_drift_bak.exists():
            shutil.copy2(dest_drift_file, dest_drift_bak)
            print(f"Backed up regular Zonda stock drift behaviour to {dest_drift_bak.name}")
        
        # Copy the tuned file
        shutil.copy2(cinque_nfs_drift_file, dest_drift_file)
        print("Successfully copied tuned drift behaviour file from Zonda Cinque.")
    else:
        print(f"Error: Target drift file not found at {dest_drift_file}")
        return

    # 3. Repack modified files to Zonda/cinque-non-NFS-stockworks/VEH_380630_MS.BIN
    print("\nRepacking modified files into regular Zonda MS.BIN...")
    cmd_pack = [
        "python", 
        "bundle_packer_unpacker.py", 
        "-p", "hpr", 
        str(unpacked_dir / "MS" / "IDs_VEH_380630_MS.json"), 
        str(stockworks_dir), 
        "VEH_380630_MS.BIN"
    ]
    res_pack = subprocess.run(cmd_pack, cwd=str(base_dir), capture_output=True, text=True)
    if res_pack.returncode != 0:
        print(f"Failed to repack! Error:\n{res_pack.stderr}")
        return

    print("Repacked successfully.")

    # 4. Verify platform byte (ensure 0x01)
    with open(src_bin, "r+b") as f:
        f.seek(8)
        pb = f.read(1)[0]
        if pb != 0x01:
            f.seek(8)
            f.write(b"\x01")
            print("Patched platform byte of repacked BIN back to 0x01.")
        else:
            print("Platform byte is correct (0x01).")

    # 5. Clean up unpacked directory to keep workspace tidy
    if unpacked_dir.exists():
        shutil.rmtree(unpacked_dir)
        print("Cleaned up unpacked temporary directory.")

    print("\nTuning transfer complete! Tuned regular Zonda MS.BIN ready in cinque-non-NFS-stockworks.")

if __name__ == "__main__":
    main()
