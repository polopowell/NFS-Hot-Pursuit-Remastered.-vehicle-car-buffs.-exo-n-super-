import shutil
from pathlib import Path

# Paths
workspace_dir = Path(__file__).resolve().parent.parent
cars_dir = workspace_dir / "Cars"
dest_root = workspace_dir / "car buffs"

def copy_files(src_dir, dest_subdir, file_list):
    dest_dir = dest_root / dest_subdir
    dest_dir.mkdir(parents=True, exist_ok=True)
    copied = 0
    for filename in file_list:
        src_path = src_dir / filename
        if src_path.exists():
            shutil.copy2(src_path, dest_dir / filename)
            copied += 1
    return copied

def main():
    if dest_root.exists():
        shutil.rmtree(dest_root, ignore_errors=True)
    dest_root.mkdir(parents=True, exist_ok=True)

    print("Organizing tunes into 'car buffs' folder...")

    # 1. Viper Tunes
    viper_src = cars_dir / "Viper" / "main tune-pre-buff"
    viper_variants = ["test 0", "test 2", "test 2.5", "test 3", "test 4"]
    viper_files = ["VEH_172882_MS.BIN", "VEH_172882_EN.BIN", "VEH_172882_ENCMP.BIN"]
    
    for var in viper_variants:
        copied = copy_files(viper_src / var, f"Viper/{var.title()}", viper_files)
        print(f"  Viper {var}: Copied {copied} files.")

    # Nimble Viper
    copied = copy_files(cars_dir / "Viper" / "nimble_fast_drift", "Viper/Nimble Drift", viper_files)
    print(f"  Viper Nimble: Copied {copied} files.")

    # 2. Zonda Tunes
    # Zonda Cinque Regular
    zonda_reg_src = cars_dir / "Zonda" / "cinque-non-NFS-stockworks"
    zonda_reg_files = ["VEH_380630_MS.BIN", "VEH_380630_EN.BIN", "VEH_380630_ENCMP.BIN"]
    copied = copy_files(zonda_reg_src, "Zonda/Cinque Regular", zonda_reg_files)
    print(f"  Zonda Cinque Regular: Copied {copied} files.")

    # Zonda Cinque NFS
    # The user has Zonda.BNDL which contains VEH_745251_MS.BIN. We can copy Zonda.BNDL and rename it to VEH_745251_MS.BIN or keep it as is.
    nfs_cinque_dest = dest_root / "Zonda" / "Cinque NFS"
    nfs_cinque_dest.mkdir(parents=True, exist_ok=True)
    if (cars_dir / "Zonda.BNDL").exists():
        shutil.copy2(cars_dir / "Zonda.BNDL", nfs_cinque_dest / "VEH_745251_MS.BIN")
        print("  Zonda Cinque NFS: Copied VEH_745251_MS.BIN.")

    # Zonda R
    zonda_r_dest = dest_root / "Zonda" / "Zonda R"
    zonda_r_dest.mkdir(parents=True, exist_ok=True)
    if (cars_dir / "ZondaR.BNDL").exists():
        shutil.copy2(cars_dir / "ZondaR.BNDL", zonda_r_dest / "VEH_745296_MS.BIN")
        print("  Zonda R: Copied VEH_745296_MS.BIN.")

    # 3. SL65 Tunes
    sl65_src = cars_dir / "SL65"
    sl65_files = ["VEH_329012_MS.BIN", "VEH_329012_EN.BIN", "VEH_329012_ENCMP.BIN"]
    copied = copy_files(sl65_src, "SL65 AMG", sl65_files)
    print(f"  SL65 AMG: Copied {copied} files.")

    # 4. Diablo SV Tunes
    diablo_src = cars_dir / "Diablo" / "diablo_slight_buffed"
    diablo_files = ["VEH_1111287_MS.BIN", "VEH_1111287_EN.BIN", "VEH_1111287_ENCMP.BIN", "VEH_1111611_MS.BIN"]
    copied = copy_files(diablo_src, "Diablo SV", diablo_files)
    print(f"  Diablo SV: Copied {copied} files.")

    # 5. GT2 Tunes
    gt2_src = cars_dir / "Gt2"
    gt2_files = ["VEH_1065090_MS.BIN", "VEH_1065135_MS.BIN"]
    copied = copy_files(gt2_src, "911 GT2", gt2_files)
    print(f"  Porsche 911 GT2: Copied {copied} files.")

    # 6. Reventon Tunes
    reventon_src = cars_dir / "Reventon"
    reventon_files = ["VEH_293008_MS.BIN", "VEH_383354_MS.BIN", "VEH_383354_EN.BIN", "VEH_383354_ENCMP.BIN"]
    copied = copy_files(reventon_src, "Reventon", reventon_files)
    print(f"  Lamborghini Reventon: Copied {copied} files.")

    print("\nSUCCESS: All tunes organized inside the 'car buffs' folder!")

if __name__ == "__main__":
    main()
