import struct
import shutil
import os
import subprocess
from pathlib import Path

# Paths
base_dir = Path(r"C:\Users\xboxF\Documents\stuff\handling_tools")
main_tune_dir = base_dir / "Viper" / "main-tune"
src_bin = main_tune_dir / "VEH_172882_MS.BIN"
bak_bin = main_tune_dir / "VEH_172882_MS.BIN.bak"
unpacked_dir = base_dir / "Viper" / "main-tune-unpacked"
inst_dir = unpacked_dir / "MS" / "GenesysInstance"

drift_file = inst_dir / "6B_A3_02_00.dat"
engine_file = inst_dir / "6F_A3_02_00.dat"

def set_f(data, offset, val):
    struct.pack_into("<f", data, offset, val)

def get_f(data, offset):
    return struct.unpack_from("<f", data, offset)[0]

def main():
    # 1. Back up the main-tune BIN file before editing
    if src_bin.exists() and not bak_bin.exists():
        shutil.copy2(src_bin, bak_bin)
        print(f"Backed up original main-tune BIN to {bak_bin.name}")

    # 2. Back up and edit the DriftBehaviour dat file
    if drift_file.exists():
        drift_bak = drift_file.with_suffix(".dat.bak")
        if not drift_bak.exists():
            shutil.copy2(drift_file, drift_bak)
            print(f"Backed up DriftBehaviour to {drift_bak.name}")
        
        dr_data = bytearray(drift_file.read_bytes())
        
        old_drag = get_f(dr_data, 0xD0)
        old_lat = get_f(dr_data, 0x188)
        old_brake = get_f(dr_data, 0xDC)
        
        # Adjust drift drag multiplier to reduce drift speed loss
        set_f(dr_data, 0xD0, 0.45)
        # Adjust lateral drag to keep drift speed high
        set_f(dr_data, 0x188, 0.75)
        # Adjust brake drag in drift
        set_f(dr_data, 0xDC, 0.35)
        
        drift_file.write_bytes(dr_data)
        print("\nTuned Drift Behaviour:")
        print(f"  Drift drag multiplier (0xD0): {old_drag} -> 0.45")
        print(f"  Lateral drag (0x188): {old_lat} -> 0.75")
        print(f"  Brake drag (0xDC): {old_brake} -> 0.35")
    else:
        print(f"Error: DriftBehaviour file not found at {drift_file}")
        return

    # 3. Back up and edit the Engine dat file
    if engine_file.exists():
        engine_bak = engine_file.with_suffix(".dat.bak")
        if not engine_bak.exists():
            shutil.copy2(engine_file, engine_bak)
            print(f"Backed up Engine to {engine_bak.name}")
            
        eng_data = bytearray(engine_file.read_bytes())
        old_nos = get_f(eng_data, 0x108)
        
        # Increase NOS power
        set_f(eng_data, 0x108, 900.0)
        
        engine_file.write_bytes(eng_data)
        print("\nTuned Engine:")
        print(f"  NOS horsepower (0x108): {old_nos} -> 900.0")
    else:
        print(f"Error: Engine file not found at {engine_file}")
        return

    # 4. Repack the bundle
    print("\nRepacking modified files into BIN bundle...")
    cmd_pack = [
        "python", 
        "bundle_packer_unpacker.py", 
        "-p", "hpr", 
        str(unpacked_dir / "MS" / "IDs_VEH_172882_MS.json"), 
        str(main_tune_dir), 
        "VEH_172882_MS.BIN"
    ]
    res_pack = subprocess.run(cmd_pack, cwd=str(base_dir), capture_output=True, text=True)
    if res_pack.returncode != 0:
        print(f"Failed to repack! Error:\n{res_pack.stderr}")
        return
    
    print("Repacked successfully.")

    # 5. Verify the repacked platform byte at 0x8 is 0x01 (matching source)
    with open(src_bin, "r+b") as f:
        f.seek(8)
        pb = f.read(1)[0]
        if pb != 0x01:
            f.seek(8)
            f.write(b"\x01")
            print("Patched platform byte of repacked BIN back to 0x01.")
        else:
            print("Platform byte is correct (0x01).")

    print("\nTuning complete and saved to main-tune directory!")

if __name__ == "__main__":
    main()
