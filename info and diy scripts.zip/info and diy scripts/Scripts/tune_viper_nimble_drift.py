import struct
import shutil
import os
import subprocess
from pathlib import Path

# Paths
workspace_dir = Path(__file__).resolve().parent.parent
pre_buff_dir = workspace_dir / "Cars" / "Viper" / "main tune-pre-buff"
nimble_dir = workspace_dir / "Cars" / "Viper" / "nimble_fast_drift"
temp_dir = workspace_dir / "Cars" / "Viper" / "rebuild-temp-nimble"
inst_dir = temp_dir / "MS" / "GenesysInstance"

def set_f(data, offset, val):
    struct.pack_into("<f", data, offset, val)

def get_f(data, offset):
    return struct.unpack_from("<f", data, offset)[0]

def main():
    # Make sure output directory exists
    nimble_dir.mkdir(parents=True, exist_ok=True)

    # 1. Clean rebuild directory and copy pre-buff MS.BIN
    if temp_dir.exists():
        shutil.rmtree(temp_dir)
    temp_dir.mkdir(parents=True, exist_ok=True)
    
    shutil.copy2(pre_buff_dir / "VEH_172882_MS.BIN", temp_dir / "VEH_172882_MS.BIN")
    print("Copied pre-buff MS.BIN to rebuild folder.")

    # 2. Unpack the MS.BIN
    print("Unpacking pre-buff stream file...")
    cmd_unpack = [
        "python", 
        "bundle_packer_unpacker.py", 
        "-u", "hpr", 
        str(temp_dir / "VEH_172882_MS.BIN"), 
        str(temp_dir / "MS")
    ]
    res_unpack = subprocess.run(cmd_unpack, cwd=str(workspace_dir), capture_output=True, text=True)
    if res_unpack.returncode != 0:
        print(f"Failed to unpack! Error:\n{res_unpack.stderr}")
        return
    print("Unpacked successfully.")

    # 3. Apply target values (Tuned down nimbleness a bit to allow more slide understeer for extended drifts)
    # Drift Behaviour
    drift_file = inst_dir / "6B_A3_02_00.dat"
    if drift_file.exists():
        dr_data = bytearray(drift_file.read_bytes())
        
        old_drag = get_f(dr_data, 0xD0)
        old_yaw_amp = get_f(dr_data, 0xD4)
        old_lat = get_f(dr_data, 0x188)
        
        # Apply edits
        set_f(dr_data, 0xD0, 0.58)      # Keep fast drift drag multiplier
        set_f(dr_data, 0xD4, 0.98)      # Keep yaw amplification
        set_f(dr_data, 0x188, 0.80)     # Keep drift lateral force
        
        drift_file.write_bytes(dr_data)
        print("\nApplied Drift Behaviour modifications:")
        print(f"  Drift drag multiplier (0xD0): {old_drag} -> 0.58")
        print(f"  Yaw force amplification (0xD4): {old_yaw_amp} -> 0.98")
        print(f"  Lateral drag (0x188): {old_lat} -> 0.80")
    else:
        print(f"Error: DriftBehaviour file not found at {drift_file}")
        return

    # Steering Behaviour
    steering_file = inst_dir / "6D_A3_02_00.dat"
    if steering_file.exists():
        st_data = bytearray(steering_file.read_bytes())
        
        old_sluggish_1 = get_f(st_data, 0x88)
        old_centering = get_f(st_data, 0x90)
        old_sluggish_2 = get_f(st_data, 0x9c)
        
        # Apply edits (Tuned down slightly from -36.0 and 36.5 to give slight understeer)
        set_f(st_data, 0x88, 35.8)      # Slightly softer turn-in (down from 36.5, stock is 35.0)
        set_f(st_data, 0x90, -33.0)     # Slightly softer self-centering (down from -36.0, stock is -30.0)
        set_f(st_data, 0x9c, 35.8)      
        
        steering_file.write_bytes(st_data)
        print("\nApplied Steering Behaviour modifications:")
        print(f"  Sluggishness limit (0x88): {old_sluggish_1} -> 35.8")
        print(f"  Centering force (0x90): {old_centering} -> -33.0")
        print(f"  Sluggishness limit (0x9c): {old_sluggish_2} -> 35.8")
    else:
        print(f"Error: SteeringBehaviour file not found at {steering_file}")
        return

    # Rear Tyre
    rear_tyre_file = inst_dir / "74_A3_02_00.dat"
    if rear_tyre_file.exists():
        rt_data = bytearray(rear_tyre_file.read_bytes())
        
        old_long_grip = get_f(rt_data, 0x220)
        old_long_shape = get_f(rt_data, 0x228)
        old_lat_slip = get_f(rt_data, 0x2e0)
        old_lat_slip_shape = get_f(rt_data, 0x2e8)
        
        # Apply edits (Tuned down slightly to allow a wider, less snappy slide extension)
        set_f(rt_data, 0x220, 0.208)    # Subtle longitudinal grip boost (down from 0.215, stock is 0.20)
        set_f(rt_data, 0x228, 42.0)     # Grip shape scaling (down from 45.0, stock is 40.0)
        set_f(rt_data, 0x2e0, 1.14)     # Subtle lateral slip factor peak (down from 1.18, stock is 1.10)
        set_f(rt_data, 0x2e8, 0.73)     # Subtle lateral slip factor shape (down from 0.76, stock is 0.70)
        
        rear_tyre_file.write_bytes(rt_data)
        print("\nApplied Rear Tyre modifications:")
        print(f"  Peak longitudinal grip (0x220): {old_long_grip} -> 0.208")
        print(f"  Peak grip curve shape (0x228): {old_long_shape} -> 42.0")
        print(f"  Lateral slip peak (0x2e0): {old_lat_slip} -> 1.14")
        print(f"  Lateral slip shape (0x2e8): {old_lat_slip_shape} -> 0.73")
    else:
        print(f"Error: Rear tyre file not found at {rear_tyre_file}")
        return

    # 4. Repack the bundle
    print("\nRepacking modified files into new MS.BIN bundle...")
    cmd_pack = [
        "python", 
        "bundle_packer_unpacker.py", 
        "-p", "hpr", 
        str(temp_dir / "MS" / "IDs_VEH_172882_MS.json"), 
        str(nimble_dir), 
        "VEH_172882_MS.BIN"
    ]
    res_pack = subprocess.run(cmd_pack, cwd=str(workspace_dir), capture_output=True, text=True)
    if res_pack.returncode != 0:
        print(f"Failed to repack! Error:\n{res_pack.stderr}")
        return
    print("Repacked successfully.")

    # 5. Verify platform byte (ensure 0x01)
    repacked_bin = nimble_dir / "VEH_172882_MS.BIN"
    with open(repacked_bin, "r+b") as f:
        f.seek(8)
        pb = f.read(1)[0]
        if pb != 0x01:
            f.seek(8)
            f.write(b"\x01")
            print("Patched platform byte of repacked BIN back to 0x01.")
        else:
            print("Platform byte is correct (0x01).")

    # 6. Copy audio streams from pre-buff dir to output folder
    print("\nCopying audio streams to output folder...")
    for filename in ["VEH_172882_EN.BIN", "VEH_172882_ENCMP.BIN"]:
        shutil.copy2(pre_buff_dir / filename, nimble_dir / filename)
        print(f"  Copied {filename}")

    # 7. Clean up rebuild temp folder
    if temp_dir.exists():
        shutil.rmtree(temp_dir)
        print("\nCleaned up rebuild temporary folder.")

    print("\nSUCCESS: 'nimble_fast_drift' variant updated in Cars/Viper/nimble_fast_drift!")

if __name__ == "__main__":
    main()
