import struct
import shutil
import os
import subprocess
from pathlib import Path

# Paths
base_dir = Path(r"C:\Users\xboxF\Documents\stuff\handling_tools")
pre_buff_dir = base_dir / "Viper" / "main tune-pre-buff"
post_buff_dir = base_dir / "Viper" / "viper tune post buff"
unpacked_dir = base_dir / "Viper" / "pre-buff-unpacked"
inst_dir = unpacked_dir / "MS" / "GenesysInstance"

src_bin = pre_buff_dir / "VEH_172882_MS.BIN"
dest_bin = post_buff_dir / "VEH_172882_MS.BIN"

def set_f(data, offset, val):
    struct.pack_into("<f", data, offset, val)

def get_f(data, offset):
    return struct.unpack_from("<f", data, offset)[0]

def main():
    # Ensure post_buff_dir exists
    post_buff_dir.mkdir(parents=True, exist_ok=True)

    # 1. Unpack pre-buff MS.BIN to pre-buff-unpacked
    if unpacked_dir.exists():
        shutil.rmtree(unpacked_dir)
    unpacked_dir.mkdir(parents=True, exist_ok=True)

    print("Unpacking user's pre-buff Viper stream bundle...")
    cmd_unpack = [
        "python", 
        "bundle_packer_unpacker.py", 
        "-u", "hpr", 
        str(src_bin), 
        str(unpacked_dir / "MS")
    ]
    res_unpack = subprocess.run(cmd_unpack, cwd=str(base_dir), capture_output=True, text=True)
    if res_unpack.returncode != 0:
        print(f"Failed to unpack! Error:\n{res_unpack.stderr}")
        return

    print("Unpacked successfully.")

    # 2. Modify DriftBehaviour: set slightly better drift speed values
    drift_file = inst_dir / "6B_A3_02_00.dat"
    if drift_file.exists():
        dr_data = bytearray(drift_file.read_bytes())
        
        old_drag = get_f(dr_data, 0xD0)
        old_lat = get_f(dr_data, 0x188)
        old_brake = get_f(dr_data, 0xDC)
        
        # Stronger buff to drift drag (less speed loss)
        set_f(dr_data, 0xD0, 0.42)
        # Stronger buff to lateral force drag (smoother drift speed)
        set_f(dr_data, 0x188, 0.70)
        # Stronger buff to brake drag in drift
        set_f(dr_data, 0xDC, 0.30)
        
        drift_file.write_bytes(dr_data)
        print("\nModified DriftBehaviour (6B_A3_02_00.dat):")
        print(f"  Drift drag multiplier (0xD0): {old_drag} -> 0.42")
        print(f"  Lateral drag (0x188): {old_lat} -> 0.70")
        print(f"  Brake drag (0xDC): {old_brake} -> 0.30")
    else:
        print(f"Error: DriftBehaviour file not found at {drift_file}")
        return

    # 3. Modify Engine: set stronger NOS power
    engine_file = inst_dir / "6F_A3_02_00.dat"
    if engine_file.exists():
        eng_data = bytearray(engine_file.read_bytes())
        
        old_nos = get_f(eng_data, 0x108)
        
        # Stronger buff to NOS horsepower
        set_f(eng_data, 0x108, 980.0)
        
        engine_file.write_bytes(eng_data)
        print("\nModified Engine (6F_A3_02_00.dat):")
        print(f"  NOS horsepower (0x108): {old_nos} -> 980.0")
    else:
        print(f"Error: Engine file not found at {engine_file}")
        return

    # 4. Repack modified files to post_buff_dir/VEH_172882_MS.BIN
    print("\nRepacking modified files into post-buff variant...")
    cmd_pack = [
        "python", 
        "bundle_packer_unpacker.py", 
        "-p", "hpr", 
        str(unpacked_dir / "MS" / "IDs_VEH_172882_MS.json"), 
        str(post_buff_dir), 
        "VEH_172882_MS.BIN"
    ]
    res_pack = subprocess.run(cmd_pack, cwd=str(base_dir), capture_output=True, text=True)
    if res_pack.returncode != 0:
        print(f"Failed to repack! Error:\n{res_pack.stderr}")
        return

    print("Repacked successfully.")

    # 5. Verify platform byte (ensure 0x01)
    with open(dest_bin, "r+b") as f:
        f.seek(8)
        pb = f.read(1)[0]
        if pb != 0x01:
            f.seek(8)
            f.write(b"\x01")
            print("Patched platform byte of repacked BIN back to 0x01.")
        else:
            print("Platform byte is correct (0x01).")

    # 6. Copy other streams from main tune-pre-buff to post-buff folder
    print("\nCopying audio stream binaries from main tune-pre-buff...")
    for filename in ["VEH_172882_EN.BIN", "VEH_172882_ENCMP.BIN"]:
        src_file = pre_buff_dir / filename
        dest_file = post_buff_dir / filename
        shutil.copy2(src_file, dest_file)
        print(f"  Copied {filename} to viper tune post buff")

    # 7. Clean up unpacked directory
    if unpacked_dir.exists():
        shutil.rmtree(unpacked_dir)
        print("\nCleaned up unpacked temporary directory.")

    print("\nTuning complete! All elevated files ready in viper tune post buff.")

if __name__ == "__main__":
    main()
