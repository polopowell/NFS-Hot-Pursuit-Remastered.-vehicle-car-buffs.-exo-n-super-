import struct
import shutil
import os
import subprocess
from pathlib import Path

# Paths
workspace_dir = Path(__file__).resolve().parent.parent
gameplay_unpack_dir = workspace_dir / "temp_gameplay_unpack"
gameplay_output_dir = workspace_dir / "temp_gameplay_output"
gamelogic_dir = Path(r"D:\Need For Speed Hot Pursuit Remastered\GAMELOGIC")

def get_f(data, offset):
    return struct.unpack_from("<f", data, offset)[0]

def set_f(data, offset, val):
    struct.pack_into("<f", data, offset, val)

def main():
    # 1. Clean/Create output folder
    if gameplay_output_dir.exists():
        shutil.rmtree(gameplay_output_dir, ignore_errors=True)
    gameplay_output_dir.mkdir(parents=True, exist_ok=True)

    # 2. Unpack GAMEPLAY.BNDL to temporary directory if not already there
    backup_file = gamelogic_dir / "GAMEPLAY.BNDL.bak"
    if not backup_file.exists():
        print("Error: Backup file GAMEPLAY.BNDL.bak not found! Cannot restore stock settings to apply subtle buff.")
        return
    
    # Clean unpack dir to ensure we get fresh files
    if gameplay_unpack_dir.exists():
        shutil.rmtree(gameplay_unpack_dir, ignore_errors=True)

    print("Unpacking original stock GAMEPLAY.BNDL from backup...")
    cmd_unpack = [
        "python", 
        "bundle_packer_unpacker.py", 
        "-u", "hpr", 
        str(backup_file), 
        str(gameplay_unpack_dir)
    ]
    res = subprocess.run(cmd_unpack, cwd=str(workspace_dir), capture_output=True, text=True)
    if res.returncode != 0:
        print(f"Unpack failed: {res.stderr}")
        return
    print("Unpacked stock file successfully.")

    # 3. Target NitrousParameters instance files
    instances_dir = gameplay_unpack_dir / "GenesysInstance"
    target_files = [
        "11_46_06_00.dat",
        "9E_E9_09_00.dat",
        "9F_E9_09_00.dat",
        "A2_04_09_00.dat",
        "A3_04_09_00.dat",
        "FA_EA_03_00.dat"
    ]

    print("\nModifying Nitrous Recharge parameters in all instances (Super OP +65% Buff):")
    for filename in target_files:
        filepath = instances_dir / filename
        if not filepath.exists():
            print(f"Warning: {filename} does not exist!")
            continue

        data = bytearray(filepath.read_bytes())
        
        # Read pointers from base struct
        drift_ptr = struct.unpack_from("<I", data, 80)[0]
        oncoming_ptr = struct.unpack_from("<I", data, 96)[0]
        nearmiss_ptr = struct.unpack_from("<I", data, 88)[0]
        slip_ptr = struct.unpack_from("<I", data, 152)[0]

        # Modify drifting values (Super OP: 1.65x rate, minspeed 45 km/h)
        drift_rate_offset = drift_ptr + 48 + 4
        drift_minspeed_offset = drift_ptr + 48 + 8
        old_drift_rate = get_f(data, drift_rate_offset)
        old_drift_min = get_f(data, drift_minspeed_offset)
        set_f(data, drift_rate_offset, old_drift_rate * 1.65)
        set_f(data, drift_minspeed_offset, 45.0)

        # Modify oncoming traffic values (Super OP: rate 1.65, minspeed 85 km/h)
        oncoming_rate_offset = oncoming_ptr + 48 + 8
        oncoming_minspeed_offset = oncoming_ptr + 48 + 4
        old_oncoming_rate = get_f(data, oncoming_rate_offset)
        old_oncoming_min = get_f(data, oncoming_minspeed_offset)
        set_f(data, oncoming_rate_offset, 1.65)
        set_f(data, oncoming_minspeed_offset, 85.0)

        # Modify near miss values (Super OP: 1.65x rate, minspeed 50 km/h)
        nearmiss_rate_offset = nearmiss_ptr + 48 + 8
        nearmiss_minspeed_offset = nearmiss_ptr + 48 + 4
        old_nearmiss_rate = get_f(data, nearmiss_rate_offset)
        old_nearmiss_min = get_f(data, nearmiss_minspeed_offset)
        set_f(data, nearmiss_rate_offset, old_nearmiss_rate * 1.65)
        set_f(data, nearmiss_minspeed_offset, 50.0)

        # Modify slipstream values (Super OP: 1.65x rate, minspeed 60 km/h)
        slip_rate_offset = slip_ptr + 48 + 8
        slip_minspeed_offset = slip_ptr + 48 + 4
        old_slip_rate = get_f(data, slip_rate_offset)
        old_slip_min = get_f(data, slip_minspeed_offset)
        set_f(data, slip_rate_offset, old_slip_rate * 1.65)
        set_f(data, slip_minspeed_offset, 60.0)

        # Write modified bytes back
        filepath.write_bytes(data)
        
        print(f"\n  File: {filename}")
        print(f"    Drifting rate: {old_drift_rate:g} -> {old_drift_rate*1.65:g} | minspeed: {old_drift_min:g} -> 45")
        print(f"    Oncoming rate: {old_oncoming_rate:g} -> 1.65 | minspeed: {old_oncoming_min:g} -> 85")
        print(f"    NearMiss rate: {old_nearmiss_rate:g} -> {old_nearmiss_rate*1.65:g} | minspeed: {old_nearmiss_min:g} -> 50")
        print(f"    Slipstream rate: {old_slip_rate:g} -> {old_slip_rate*1.65:g} | minspeed: {old_slip_min:g} -> 60")

    # 4. Repack the BNDL
    print("\nRepacking modified files into GAMEPLAY.BNDL...")
    cmd_pack = [
        "python", 
        "bundle_packer_unpacker.py", 
        "-p", "hpr", 
        str(gameplay_unpack_dir / "IDs_GAMEPLAY.json"), 
        str(gameplay_output_dir), 
        "GAMEPLAY.BNDL"
    ]
    res_pack = subprocess.run(cmd_pack, cwd=str(workspace_dir), capture_output=True, text=True)
    if res_pack.returncode != 0:
        print(f"Repack failed: {res_pack.stderr}")
        return
    print("Repacked successfully.")

    # 5. Patch platform byte
    output_bin = gameplay_output_dir / "GAMEPLAY.BNDL"
    with open(output_bin, "r+b") as f:
        f.seek(8)
        pb = f.read(1)[0]
        if pb != 0x01:
            f.seek(8)
            f.write(b"\x01")
            print("Patched GAMEPLAY.BNDL platform byte to 0x01.")
        else:
            print("GAMEPLAY.BNDL platform byte is correct (0x01).")

    # 6. Copy modified file to game folder (backup already exists)
    original_file = gamelogic_dir / "GAMEPLAY.BNDL"
    shutil.copy2(output_bin, original_file)
    print("\nCopied Super OP modified GAMEPLAY.BNDL to game folder.")

    # 7. Clean up temporary unpack directories
    shutil.rmtree(gameplay_unpack_dir, ignore_errors=True)
    shutil.rmtree(gameplay_output_dir, ignore_errors=True)
    print("Cleaned up temporary directories.")
    
    print("\nSUCCESS: Nitrous recharge rates updated with Super OP +65% buff values!")

if __name__ == "__main__":
    main()
