import shutil
from pathlib import Path

# Paths
workspace_dir = Path(__file__).resolve().parent.parent
dest_root = workspace_dir / "info and diy scripts"

def main():
    if dest_root.exists():
        shutil.rmtree(dest_root, ignore_errors=True)
    dest_root.mkdir(parents=True, exist_ok=True)

    print("Organizing guides and scripts into 'info and diy scripts'...")

    # 1. Copy Guides
    guides_to_copy = [
        "DRIFT_TUNING_README.md",
        "SLIPSTREAM_REVERSE_ENGINEERING.md",
    ]
    for guide in guides_to_copy:
        src = workspace_dir / guide
        if src.exists():
            shutil.copy2(src, dest_root / guide)
            print(f"  Copied guide: {guide}")

    # Copy the car buffs README as well to this folder just in case
    car_buffs_readme = workspace_dir / "car buffs" / "README.md"
    if car_buffs_readme.exists():
        shutil.copy2(car_buffs_readme, dest_root / "CAR_BUFFS_GUIDE.md")
        print("  Copied car buffs README as CAR_BUFFS_GUIDE.md")

    # 2. Copy Scripts directory
    scripts_src = workspace_dir / "Scripts"
    scripts_dest = dest_root / "Scripts"
    if scripts_src.exists():
        shutil.copytree(scripts_src, scripts_dest, dirs_exist_ok=True)
        print("  Copied Scripts/ folder.")

    # 3. Copy Cheat Tables and debug files from toolbox
    toolbox_src = workspace_dir / "toolbox"
    toolbox_dest = dest_root / "toolbox"
    if toolbox_src.exists():
        shutil.copytree(toolbox_src, toolbox_dest, dirs_exist_ok=True)
        print("  Copied toolbox/ folder.")

    print("\nSUCCESS: All guides and scripts organized inside 'info and diy scripts'!")

if __name__ == "__main__":
    main()
