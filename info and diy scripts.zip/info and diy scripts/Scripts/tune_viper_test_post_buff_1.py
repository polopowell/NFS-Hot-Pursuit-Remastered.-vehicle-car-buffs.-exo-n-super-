import struct
import shutil
import os
import subprocess
from pathlib import Path

# Paths
workspace_dir = Path(__file__).resolve().parent.parent
stock_dir = workspace_dir / "Cars" / "Viper" / "stockviper"
test_buff_dir = workspace_dir / "Cars" / "Viper" / "test post buff 1"
temp_dir = workspace_dir / "Cars" / "Viper" / "rebuild-temp-test-1"
inst_dir = temp_dir / "MS" / "GenesysInstance"

# Game paths
game_vehicles = Path(r"D:\Need For Speed Hot Pursuit Remastered\VEHICLES")

def set_f(data, offset, val):
    struct.pack_into("<f", data, offset, val)

def get_f(data, offset):
    return struct.unpack_from("<f", data, offset)[0]

def main():
    # Make sure output directory exists
    test_buff_dir.mkdir(parents=True, exist_ok=True)

    # 1. Clean rebuild directory and copy stock MS.BIN
    if temp_dir.exists():
        shutil.rmtree(temp_dir)
    temp_dir.mkdir(parents=True, exist_ok=True)
    
    shutil.copy2(stock_dir / "VEH_172882_MS.BIN", temp_dir / "VEH_172882_MS.BIN")
    print("Copied stock MS.BIN to rebuild folder.")

    # 2. Unpack the stock MS.BIN
    print("Unpacking stock stream file...")
    cmd_unpack = [
        "python", 
        "bundle_packer_unpacker.py", 
        "-u", "hpr", 
        str(temp_dir / "VEH_172882_MS.BIN"), 
        str(temp_dir / "MS")
    ]
    res_unpack = subprocess.run(cmd_unpack, cwd=str(workspace_dir), capture_output=True, text=True)
    if res_unpack.returncode != 0:
        print(f"Failed to unpack! Error:\n{res_unpack.stderr}")
        return
    print("Unpacked stock successfully.")

    # 3. Apply target values
    # Drift Behaviour
    drift_file = inst_dir / "6B_A3_02_00.dat"
    if drift_file.exists():
        dr_data = bytearray(drift_file.read_bytes())
        
        old_drag = get_f(dr_data, 0xD0)
        old_yaw_amp = get_f(dr_data, 0xD4)
        old_brake = get_f(dr_data, 0xDC)
        old_lat = get_f(dr_data, 0x188)
        
        # Apply edits
        set_f(dr_data, 0xD0, 0.42)      # Drift drag (Post-buff baseline)
        set_f(dr_data, 0xD4, 0.70)      # Yaw force amplification (SL65 blend: down from 1.1)
        set_f(dr_data, 0xDC, 0.30)      # Brake drag in drift (Post-buff baseline)
        set_f(dr_data, 0x188, 0.70)     # Lateral drag in drift (Post-buff baseline)
        
        drift_file.write_bytes(dr_data)
        print("\nApplied Drift Behaviour modifications:")
        print(f"  Drift drag multiplier (0xD0): {old_drag} -> 0.42")
        print(f"  Yaw force amplification (0xD4): {old_yaw_amp} -> 0.70")
        print(f"  Brake drag (0xDC): {old_brake} -> 0.30")
        print(f"  Lateral drag (0x188): {old_lat} -> 0.70")
    else:
        print(f"Error: DriftBehaviour file not found at {drift_file}")
        return

    # Steering Behaviour
    steering_file = inst_dir / "6D_A3_02_00.dat"
    if steering_file.exists():
        st_data = bytearray(steering_file.read_bytes())
        
        old_sluggish_1 = get_f(st_data, 0x88)
        old_centering = get_f(st_data, 0x90)
        old_sluggish_2 = get_f(st_data, 0x9c)
        
        # Apply edits (Steering_angle_curve offsets 0x88, 0x90, 0x9c)
        set_f(st_data, 0x88, 38.0)      # Steering sluggishness (SL65 blend: up from 35.0)
        set_f(st_data, 0x90, -45.0)     # Centering correction force (SL65 blend: stronger centering)
        set_f(st_data, 0x9c, 38.0)      # Secondary sluggishness limit (SL65 blend: up from 35.0)
        
        steering_file.write_bytes(st_data)
        print("\nApplied Steering Behaviour modifications:")
        print(f"  Sluggishness limit (0x88): {old_sluggish_1} -> 38.0")
        print(f"  Centering force (0x90): {old_centering} -> -45.0")
        print(f"  Sluggishness limit (0x9c): {old_sluggish_2} -> 38.0")
    else:
        print(f"Error: SteeringBehaviour file not found at {steering_file}")
        return

    # Engine
    engine_file = inst_dir / "6F_A3_02_00.dat"
    if engine_file.exists():
        eng_data = bytearray(engine_file.read_bytes())
        
        old_nos = get_f(eng_data, 0x108)
        
        # Apply edits
        set_f(eng_data, 0x108, 1050.0)   # NOS Power (Up from 980.0)
        
        engine_file.write_bytes(eng_data)
        print("\nApplied Engine modifications:")
        print(f"  NOS horsepower (0x108): {old_nos} -> 1050.0")
    else:
        print(f"Error: Engine file not found at {engine_file}")
        return

    # Rear Tyre
    rear_tyre_file = inst_dir / "74_A3_02_00.dat"
    if rear_tyre_file.exists():
        rt_data = bytearray(rear_tyre_file.read_bytes())
        
        old_long_grip = get_f(rt_data, 0x220)
        old_long_shape = get_f(rt_data, 0x228)
        old_lat_slip = get_f(rt_data, 0x2e0)
        old_lat_slip_shape = get_f(rt_data, 0x2e8)
        
        # Apply edits (Long_Grip_Curve & Lateral_Slip_Factors)
        set_f(rt_data, 0x220, 0.24)     # Peak longitudinal grip (SL65 blend: up from 0.20)
        set_f(rt_data, 0x228, 45.0)     # Peak shape scaling (SL65 blend: up from 40.0)
        set_f(rt_data, 0x2e0, 1.30)     # Lateral slip factor peak (SL65 blend: up from 1.10)
        set_f(rt_data, 0x2e8, 0.90)     # Lateral slip factor shape (SL65 blend: up from 0.70)
        
        rear_tyre_file.write_bytes(rt_data)
        print("\nApplied Rear Tyre modifications:")
        print(f"  Peak longitudinal grip (0x220): {old_long_grip} -> 0.24")
        print(f"  Peak grip curve shape (0x228): {old_long_shape} -> 45.0")
        print(f"  Lateral slip peak (0x2e0): {old_lat_slip} -> 1.30")
        print(f"  Lateral slip shape (0x2e8): {old_lat_slip_shape} -> 0.90")
    else:
        print(f"Error: Rear tyre file not found at {rear_tyre_file}")
        return

    # 4. Repack the bundle
    print("\nRepacking modified files into new MS.BIN bundle...")
    cmd_pack = [
        "python", 
        "bundle_packer_unpacker.py", 
        "-p", "hpr", 
        str(temp_dir / "MS" / "IDs_VEH_172882_MS.json"), 
        str(test_buff_dir), 
        "VEH_172882_MS.BIN"
    ]
    res_pack = subprocess.run(cmd_pack, cwd=str(workspace_dir), capture_output=True, text=True)
    if res_pack.returncode != 0:
        print(f"Failed to repack! Error:\n{res_pack.stderr}")
        return
    print("Repacked successfully.")

    # 5. Verify platform byte (ensure 0x01)
    repacked_bin = test_buff_dir / "VEH_172882_MS.BIN"
    with open(repacked_bin, "r+b") as f:
        f.seek(8)
        pb = f.read(1)[0]
        if pb != 0x01:
            f.seek(8)
            f.write(b"\x01")
            print("Patched platform byte of repacked BIN back to 0x01.")
        else:
            print("Platform byte is correct (0x01).")

    # 6. Copy audio streams from stockviper to test post buff 1 folder
    print("\nCopying stock audio streams to test post buff 1 folder...")
    for filename in ["VEH_172882_EN.BIN", "VEH_172882_ENCMP.BIN"]:
        shutil.copy2(stock_dir / filename, test_buff_dir / filename)
        print(f"  Copied {filename} to test post buff 1 folder.")

    # 7. Safe Install to game directory
    print("\nInstalling files to game vehicles directory...")
    if game_vehicles.exists():
        for filename in ["VEH_172882_MS.BIN", "VEH_172882_EN.BIN", "VEH_172882_ENCMP.BIN"]:
            src_file = test_buff_dir / filename
            dest_file = game_vehicles / filename
            bak_file = game_vehicles / f"{filename}.bak"
            
            # Back up original game file if backup does not already exist
            if dest_file.exists() and not bak_file.exists():
                shutil.copy2(dest_file, bak_file)
                print(f"  Backed up original {filename} to {bak_file.name}")
            
            # Copy to game folder
            shutil.copy2(src_file, dest_file)
            print(f"  Copied and installed {filename}")
    else:
        print(f"Warning: Game directory {game_vehicles} not found. Skipping game installation.")

    # 8. Clean up rebuild temp folder
    if temp_dir.exists():
        shutil.rmtree(temp_dir)
        print("\nCleaned up rebuild temporary folder.")

    print("\nSUCCESS: Clean rebuild and game installation complete for 'test post buff 1'!")

if __name__ == "__main__":
    main()
