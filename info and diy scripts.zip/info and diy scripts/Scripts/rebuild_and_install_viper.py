import struct
import shutil
import os
import subprocess
from pathlib import Path

# Paths
base_dir = Path(r"C:\Users\xboxF\Documents\stuff\handling_tools")
stock_dir = base_dir / "Viper" / "stockviper"
post_buff_dir = base_dir / "Viper" / "viper tune post buff"
temp_dir = base_dir / "Viper" / "rebuild-temp"
inst_dir = temp_dir / "MS" / "GenesysInstance"

# Game paths
game_vehicles = Path(r"D:\Need For Speed Hot Pursuit Remastered\VEHICLES")

def set_f(data, offset, val):
    struct.pack_into("<f", data, offset, val)

def get_f(data, offset):
    return struct.unpack_from("<f", data, offset)[0]

def main():
    # Make sure output directory exists
    post_buff_dir.mkdir(parents=True, exist_ok=True)

    # 1. Clean rebuild directory and copy stock MS.BIN
    if temp_dir.exists():
        shutil.rmtree(temp_dir)
    temp_dir.mkdir(parents=True, exist_ok=True)
    
    shutil.copy2(stock_dir / "VEH_172882_MS.BIN", temp_dir / "VEH_172882_MS.BIN")
    print("Copied stock MS.BIN to rebuild folder.")

    # 2. Unpack the stock MS.BIN
    print("Unpacking stock stream file...")
    cmd_unpack = [
        "python", 
        "bundle_packer_unpacker.py", 
        "-u", "hpr", 
        str(temp_dir / "VEH_172882_MS.BIN"), 
        str(temp_dir / "MS")
    ]
    res_unpack = subprocess.run(cmd_unpack, cwd=str(base_dir), capture_output=True, text=True)
    if res_unpack.returncode != 0:
        print(f"Failed to unpack! Error:\n{res_unpack.stderr}")
        return
    print("Unpacked stock successfully.")

    # 3. Apply target values (pre-buff handling + post-buff speed adjustments)
    # Drift Behaviour
    drift_file = inst_dir / "6B_A3_02_00.dat"
    if drift_file.exists():
        dr_data = bytearray(drift_file.read_bytes())
        
        # Original stock values for printing
        old_drag = get_f(dr_data, 0xD0)
        old_width = get_f(dr_data, 0xD8)
        old_brake = get_f(dr_data, 0xDC)
        old_counter = get_f(dr_data, 0x138)
        old_lat = get_f(dr_data, 0x188)
        old_exit = get_f(dr_data, 0x240)
        
        # Apply edits
        set_f(dr_data, 0xD0, 0.42)      # Drift drag (Post-buff)
        set_f(dr_data, 0xD8, 0.895)     # Slide width (Pre-buff favorite)
        set_f(dr_data, 0xDC, 0.30)      # Brake drag (Post-buff)
        set_f(dr_data, 0x138, 11950.0)  # Counter torque damping (Pre-buff favorite)
        set_f(dr_data, 0x188, 0.70)      # Lateral drag (Post-buff)
        set_f(dr_data, 0x240, 3.20)      # Drift exit delay (Pre-buff favorite)
        
        drift_file.write_bytes(dr_data)
        print("\nApplied Drift Behaviour modifications:")
        print(f"  Drift drag multiplier (0xD0): {old_drag} -> 0.42 (Tuned)")
        print(f"  Slide width (0xD8): {old_width} -> 0.895 (Tuned)")
        print(f"  Brake drag (0xDC): {old_brake} -> 0.30 (Tuned)")
        print(f"  Counter torque damping (0x138): {old_counter} -> 11950.0 (Tuned)")
        print(f"  Lateral drag (0x188): {old_lat} -> 0.70 (Tuned)")
        print(f"  Drift exit delay (0x240): {old_exit} -> 3.20 (Tuned)")
    else:
        print(f"Error: DriftBehaviour file not found at {drift_file}")
        return

    # Engine
    engine_file = inst_dir / "6F_A3_02_00.dat"
    if engine_file.exists():
        eng_data = bytearray(engine_file.read_bytes())
        old_nos = get_f(eng_data, 0x108)
        
        # Apply NOS power
        set_f(eng_data, 0x108, 980.0)    # NOS horsepower (Post-buff)
        
        engine_file.write_bytes(eng_data)
        print("\nApplied Engine modifications:")
        print(f"  NOS horsepower (0x108): {old_nos} -> 980.0 (Tuned)")
    else:
        print(f"Error: Engine file not found at {engine_file}")
        return

    # 4. Repack the bundle to the output folder
    print("\nRepacking modified files into new MS.BIN bundle...")
    cmd_pack = [
        "python", 
        "bundle_packer_unpacker.py", 
        "-p", "hpr", 
        str(temp_dir / "MS" / "IDs_VEH_172882_MS.json"), 
        str(post_buff_dir), 
        "VEH_172882_MS.BIN"
    ]
    res_pack = subprocess.run(cmd_pack, cwd=str(base_dir), capture_output=True, text=True)
    if res_pack.returncode != 0:
        print(f"Failed to repack! Error:\n{res_pack.stderr}")
        return
    print("Repacked successfully.")

    # 5. Verify platform byte (ensure 0x01)
    repacked_bin = post_buff_dir / "VEH_172882_MS.BIN"
    with open(repacked_bin, "r+b") as f:
        f.seek(8)
        pb = f.read(1)[0]
        if pb != 0x01:
            f.seek(8)
            f.write(b"\x01")
            print("Patched platform byte of repacked BIN back to 0x01.")
        else:
            print("Platform byte is correct (0x01).")

    # 6. Copy audio streams from stockviper to post-buff folder
    print("\nCopying stock audio streams to post-buff folder...")
    for filename in ["VEH_172882_EN.BIN", "VEH_172882_ENCMP.BIN"]:
        shutil.copy2(stock_dir / filename, post_buff_dir / filename)
        print(f"  Copied {filename} to post-buff folder.")

    # 7. Safe Install to game directory
    print("\nInstalling files to game vehicles directory...")
    if game_vehicles.exists():
        for filename in ["VEH_172882_MS.BIN", "VEH_172882_EN.BIN", "VEH_172882_ENCMP.BIN"]:
            src_file = post_buff_dir / filename
            dest_file = game_vehicles / filename
            bak_file = game_vehicles / f"{filename}.bak"
            
            # Back up original game file if backup does not already exist
            if dest_file.exists() and not bak_file.exists():
                shutil.copy2(dest_file, bak_file)
                print(f"  Backed up original {filename} to {bak_file.name}")
            
            # Copy to game folder
            shutil.copy2(src_file, dest_file)
            print(f"  Copied and installed {filename}")
    else:
        print(f"Warning: Game directory {game_vehicles} not found. Skipping game installation.")

    # 8. Clean up rebuild temp folder
    if temp_dir.exists():
        shutil.rmtree(temp_dir)
        print("\nCleaned up rebuild temporary folder.")

    print("\nSUCCESS: Clean rebuild and game installation complete!")

if __name__ == "__main__":
    main()
