import os

def get_strings(filename, min_len=4):
    with open(filename, 'rb') as f:
        data = f.read()
    
    result = ""
    current = ""
    for b in data:
        if 32 <= b <= 126:
            current += chr(b)
        else:
            if len(current) >= min_len:
                result += current + "\n"
            current = ""
    if len(current) >= min_len:
        result += current + "\n"
    return result

directory = r"d:\Need For Speed Hot Pursuit Remastered\handling_tools\GAMEPLAY_UNPACKED\GenesysInstance"
found = False
for root, dirs, files in os.walk(directory):
    for file in files:
        if file.endswith('.dat'):
            filepath = os.path.join(root, file)
            strs = get_strings(filepath)
            if "drift" in strs.lower() or "grip" in strs.lower() or "handling" in strs.lower():
                print(f"Found in {file}:")
                for line in strs.split('\n'):
                    if "drift" in line.lower() or "grip" in line.lower() or "handling" in line.lower():
                        print(f"  {line}")
                found = True

if not found:
    print("No readable handling strings found. The data is entirely hashed/compiled.")
