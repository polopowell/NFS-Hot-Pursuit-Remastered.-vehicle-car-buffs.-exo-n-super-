import struct
import shutil
import os
import subprocess
from pathlib import Path

# Paths
workspace_dir = Path(__file__).resolve().parent.parent
gameplay_unpack_dir = workspace_dir / "temp_gameplay_backup_unpack"
gameplay_output_dir = workspace_dir / "temp_gameplay_backup_output"
gamelogic_dir = Path(r"D:\Need For Speed Hot Pursuit Remastered\GAMELOGIC")
backups_dest_dir = workspace_dir / "GameplayBackups"

def get_f(data, offset):
    return struct.unpack_from("<f", data, offset)[0]

def set_f(data, offset, val):
    struct.pack_into("<f", data, offset, val)

def clean_temp_dirs():
    if gameplay_unpack_dir.exists():
        shutil.rmtree(gameplay_unpack_dir, ignore_errors=True)
    if gameplay_output_dir.exists():
        shutil.rmtree(gameplay_output_dir, ignore_errors=True)

def generate_bndl(multiplier, oncoming_val, drift_speed, oncoming_speed, nearmiss_speed, slipstream_speed, output_name):
    # Clean temp dirs first
    clean_temp_dirs()
    gameplay_output_dir.mkdir(parents=True, exist_ok=True)

    backup_file = gamelogic_dir / "GAMEPLAY.BNDL.bak"
    if not backup_file.exists():
        print(f"Error: {backup_file} not found. Cannot proceed.")
        return False

    # Unpack stock
    cmd_unpack = [
        "python", 
        "bundle_packer_unpacker.py", 
        "-u", "hpr", 
        str(backup_file), 
        str(gameplay_unpack_dir)
    ]
    res = subprocess.run(cmd_unpack, cwd=str(workspace_dir), capture_output=True, text=True)
    if res.returncode != 0:
        print(f"Unpack failed: {res.stderr}")
        return False

    # Modify
    instances_dir = gameplay_unpack_dir / "GenesysInstance"
    target_files = [
        "11_46_06_00.dat",
        "9E_E9_09_00.dat",
        "9F_E9_09_00.dat",
        "A2_04_09_00.dat",
        "A3_04_09_00.dat",
        "FA_EA_03_00.dat"
    ]

    for filename in target_files:
        filepath = instances_dir / filename
        if not filepath.exists():
            continue

        data = bytearray(filepath.read_bytes())
        
        drift_ptr = struct.unpack_from("<I", data, 80)[0]
        oncoming_ptr = struct.unpack_from("<I", data, 96)[0]
        nearmiss_ptr = struct.unpack_from("<I", data, 88)[0]
        slip_ptr = struct.unpack_from("<I", data, 152)[0]

        # Modify drifting values
        drift_rate_offset = drift_ptr + 48 + 4
        drift_minspeed_offset = drift_ptr + 48 + 8
        old_drift_rate = get_f(data, drift_rate_offset)
        set_f(data, drift_rate_offset, old_drift_rate * multiplier)
        set_f(data, drift_minspeed_offset, drift_speed)

        # Modify oncoming traffic values
        oncoming_rate_offset = oncoming_ptr + 48 + 8
        oncoming_minspeed_offset = oncoming_ptr + 48 + 4
        set_f(data, oncoming_rate_offset, oncoming_val)
        set_f(data, oncoming_minspeed_offset, oncoming_speed)

        # Modify near miss values
        nearmiss_rate_offset = nearmiss_ptr + 48 + 8
        nearmiss_minspeed_offset = nearmiss_ptr + 48 + 4
        old_nearmiss_rate = get_f(data, nearmiss_rate_offset)
        set_f(data, nearmiss_rate_offset, old_nearmiss_rate * multiplier)
        set_f(data, nearmiss_minspeed_offset, nearmiss_speed)

        # Modify slipstream values
        slip_rate_offset = slip_ptr + 48 + 8
        slip_minspeed_offset = slip_ptr + 48 + 4
        old_slip_rate = get_f(data, slip_rate_offset)
        set_f(data, slip_rate_offset, old_slip_rate * multiplier)
        set_f(data, slip_minspeed_offset, slipstream_speed)

        filepath.write_bytes(data)

    # Repack
    cmd_pack = [
        "python", 
        "bundle_packer_unpacker.py", 
        "-p", "hpr", 
        str(gameplay_unpack_dir / "IDs_GAMEPLAY.json"), 
        str(gameplay_output_dir), 
        "GAMEPLAY.BNDL"
    ]
    res_pack = subprocess.run(cmd_pack, cwd=str(workspace_dir), capture_output=True, text=True)
    if res_pack.returncode != 0:
        print(f"Repack failed: {res_pack.stderr}")
        return False

    # Patch platform byte
    output_bin = gameplay_output_dir / "GAMEPLAY.BNDL"
    with open(output_bin, "r+b") as f:
        f.seek(8)
        pb = f.read(1)[0]
        if pb != 0x01:
            f.seek(8)
            f.write(b"\x01")

    # Copy to destination
    dest_path = backups_dest_dir / output_name
    shutil.copy2(output_bin, dest_path)
    print(f"Successfully created: {dest_path.name}")
    return True

def main():
    backups_dest_dir.mkdir(parents=True, exist_ok=True)

    # 1. Copy Stock GAMEPLAY.BNDL
    backup_file = gamelogic_dir / "GAMEPLAY.BNDL.bak"
    if backup_file.exists():
        stock_dest = backups_dest_dir / "GAMEPLAY_STOCK.BNDL"
        shutil.copy2(backup_file, stock_dest)
        print(f"Successfully copied stock gameplay file to: {stock_dest.name}")
    else:
        # Try copying from game folder if no bak exists (though bak should exist)
        game_file = gamelogic_dir / "GAMEPLAY.BNDL"
        if game_file.exists():
            stock_dest = backups_dest_dir / "GAMEPLAY_STOCK.BNDL"
            shutil.copy2(game_file, stock_dest)
            print(f"Warning: GAMEPLAY.BNDL.bak not found, copied current GAMEPLAY.BNDL as GAMEPLAY_STOCK.BNDL: {stock_dest.name}")

    # 2. Generate Subtle +28% Buff Gameplay file
    print("Generating GAMEPLAY_SUBTLE_28.BNDL...")
    generate_bndl(1.28, 1.28, 47.0, 90.0, 52.0, 65.0, "GAMEPLAY_SUBTLE_28.BNDL")

    # 3. Generate OP +40% Buff Gameplay file
    print("Generating GAMEPLAY_OP_40.BNDL...")
    generate_bndl(1.40, 1.40, 47.0, 90.0, 52.0, 65.0, "GAMEPLAY_OP_40.BNDL")

    # 4. Generate Super OP +65% Buff Gameplay file
    print("Generating GAMEPLAY_OP_65.BNDL...")
    generate_bndl(1.65, 1.65, 45.0, 85.0, 50.0, 60.0, "GAMEPLAY_OP_65.BNDL")

    # Clean up
    clean_temp_dirs()
    print("Done generating all gameplay backups!")

if __name__ == "__main__":
    main()
