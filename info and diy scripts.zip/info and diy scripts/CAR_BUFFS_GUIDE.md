# NFS Hot Pursuit Remastered — Car Buffs & Tuning Guide

Welcome to the **Car Buffs** repository. This folder contains pre-compiled custom vehicle stream files (`.BIN`) for various cars in *Need for Speed: Hot Pursuit Remastered*, along with a guide explaining how you can tune these parameters yourself and a showcase of custom vehicle configurations.

---

### The Client-Side Vulnerability
In *Hot Pursuit Remastered*, all vehicle handling, engine dynamics, torque curves, and nitrous regeneration parameters are loaded directly from **local, client-side files** (`VEHICLES/` and `GAMELOGIC/`). 
* The game performs **zero online verification** or checksum hash checks on these files before you join online matchmaking or submit a time.
* If you modify your vehicle's files locally, your customized physics are carried directly into multiplayer sessions and online leaderboards.

### The "Invisible" Tweak
While the extreme configurations in this folder (like `Test 4` with 1100 HP) are made for offline fun, anyone with basic knowledge of the game engine can compile a **"subtle buff."**
* By adding a microscopic **+2% to +3% base engine torque**, slightly reducing drift drag by **-0.05**, or bumping nitrous recovery rates by a tiny margin, a player can gain a massive advantage over 4 minutes.
* This run will look totally legit to others playing if you tune your vehicle correctly and moderately. 

Because of this vulnerability, competitive authority and egocentrism over "world records" are completely pointless. The leaderboards are a security joke. Stop taking yourself so seriously and just have fun with the sandbox.

---

## 2. Installation Guide

To install any of the custom tunes included in this folder:

1. Navigate to your game's vehicles directory: 
   `D:\Need For Speed Hot Pursuit Remastered\VEHICLES\` (or wherever your game is installed).
2. **Back up your original game files** by copying them and appending `.bak` to the name (e.g., rename `VEH_172882_MS.BIN` to `VEH_172882_MS.BIN.bak`).
3. Copy the compiled `.BIN` files from one of the folders inside `car buffs/` (e.g., `Viper/Test 3/`) and paste them directly into the game's `VEHICLES/` folder.
4. Launch the game and enjoy.

---

## 3. How to Tune Your Own Vehicles (The Genesys System)

Handling and physics data in this game uses Criterion's **"Genesys"** binary data system. A vehicle's main stream file (e.g., `VEH_XXXXXX_MS.BIN`) is a packed archive that can be unpacked into editable `.dat` files representing class instances.

### The Unpacking Workflow
Using the core tool `bundle_packer_unpacker.py`:
1. **Unpack:** `python bundle_packer_unpacker.py -u hpr "path/to/VEH_XXXXXX_MS.BIN" "UnpackFolder"`
2. **Modify:** Locate the target instance `.dat` file inside `UnpackFolder/MS/GenesysInstance/` and edit the binary values (little-endian 32-bit floats) at specific byte offsets.
3. **Repack:** `python bundle_packer_unpacker.py -p hpr "UnpackFolder/MS/IDs_VEH_XXXXXX_MS.json" "." "OutputFolder"`
4. **Patch:** Verify that the platform byte at offset `0x08` of the repacked file is set to `0x01` (PC format).

### Key Handling Offsets (`DriftBehaviour` Instance)
Locate the file containing the `DriftBehaviour` type hash (`A2 8A 01 00`). Key 32-bit float offsets include:

| Parameter | Offset (Hex) | Description |
|-----------|--------------|-------------|
| **Drift Drag** | `0xD0` | Forward drag multiplier during drifts. Lower values (e.g., `0.58`) allow you to slide without losing speed. |
| **Yaw Amplification** | `0xD4` | Rotational snap force. Setting this closer to `0.98` creates a smooth, shallow F1-like "gliding" posture. |
| **Slide Width** | `0xD8` | Controls lateral slide displacement. Lowering to `0.85` holds the car tighter to the road, preventing wall collisions. |
| **Lateral Drag** | `0x188` | Sideways slip resistance. Lowering to `0.80` lets the tires glide over the asphalt with minimal speed decay. |
| **Drift Exit Delay** | `0x240` | Slide exit window. Lower values (e.g., `2.90`) allow you to sustain long, sweeping slides over straightaways. |

### Key Engine Offsets (`Engine` Instance)
Locate the file containing the `Engine` type hash (`98 8A 01 00`). Key 32-bit float offsets include:

* **Max Speed Governor (Offset `176` / `0xB0`):** Controls the top-end speed limiter (default `202.0` m/s). Raising this allows higher velocities.
* **NOS Horsepower (Offset `264` / `0x108`):** Controls the push given by nitrous boost (default `600.0` HP). 
* **Base Engine Torque (Offset `268` / `0x10C`):** Adjusts low-end straight-line acceleration torque (default `720.0`).
* **Peak Engine Torque (Offset `272` / `0x110`):** Adjusts mid-to-high-end acceleration torque (default `800.0`).

---

## 4. Summary of Included Dodge Viper ACR Custom Stages

* **Test 0 (Composed Chassis / Stock Power):** The exact F1-glide handling chassis from Test 3, but with all engine performance metrics (NOS, torque, speed governor) kept completely stock.
* **Test 2 (RB21 F1 Glide):** The initial F1-glide setup featuring low-drag gliding, tight lane containment, and an extended drift window.
* **Test 2.5 (Balanced Glide/Power):** Sits halfway between stock power and Test 3. Features the F1 glide handling with a moderate `700 HP` NOS, +3.5% engine torque, and `203.5 m/s` (+5.4 km/h) speed governor.
* **Test 3 (OP Glide/Power):** The ultimate sweet spot. Blends the glide chassis with **800 HP** NOS, +7% engine torque, and a **205.0 m/s** (+10.8 km/h) governor. Extremely smooth and incredibly fast.
* **Test 4 (Extreme OP Glide/Power):** The limits of physical driveability. Integrates the glide chassis with a massive **1100 HP** NOS, **+25% engine torque**, and a **212 m/s** (+36.0 km/h) speed governor.
